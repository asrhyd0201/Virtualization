package sample;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class Test1 extends DefaultHandler{

	private boolean text,title,id;
    private BufferedWriter outputStream;
    private StringBuffer sb,value;
    public TreeMap <String,StringBuffer>data;
    public String pageTitle,pageId;
    private String tempdata;
    private String regexp1,regexp2,temp;
	private StopWordRemoval sw;
	private Porter pstem;
	StringBuffer word;
    /*outlinks has title of other page->visible part of page,seperated by '-:'*/
    public int within_urlcount,outside_urlcount,linkcount;
	Test1(String inputfile,String outputfile)
	{
		try 
		{
			regexp1="\\n+|[^\\p{ASCII}]+|"+System.getProperty("line.separator")+"+";
			regexp2="(\\{\\{[cC](ite|itation).+?\\}\\})|(<ref.*?>.+?</ref>)|(<.+?>)";
			outputStream=null;
			within_urlcount=outside_urlcount=linkcount=0;
			text=title=id=false;
			data=new TreeMap<String,StringBuffer>();
			value=new StringBuffer(1000);
			sb = new StringBuffer(16000);
			sw=new StopWordRemoval();
			pstem=new Porter();
			word=new StringBuffer(2000);
			new StringBuffer(100);
			outputStream = new BufferedWriter(new FileWriter(outputfile));
			SAXParserFactory factory = SAXParserFactory.newInstance();
	         SAXParser saxParser = factory.newSAXParser();
	         saxParser.parse(new File(inputfile), this);
	    } 
		catch (Exception e) 
		{
			e.printStackTrace();
	    }
	}
	
	public static void main(String[] args) throws Exception
	{
	   String infile=null,outfile=null;
	   infile=new String("C:/Users/Manikanta/Desktop/New folder (5)/IRE/src/sample/wiki1mb.xml");
	   outfile=new String("temp.txt");
	   new Test1(infile,outfile);
	}

	public void startElement(String uri,String localName,String qname,Attributes attr) throws SAXException
	{ 
		if(qname.equals("text"))
		{
			text=true;
		}
		if(qname.equalsIgnoreCase("title"))
		{
			title=true;
		}
	}
	
	public void endElement(String uri,String localName,String qname) throws SAXException
	{ 
		if(qname.equals("text"))
		{
			//System.out.println(pageId);
			tempdata=new String(sb);
			tempdata=replacePatternBy(regexp1," ");
			getInfobox();
			getCategory();
			tempdata=replacePatternBy("http://.+?(\\s|>|\\]|\\})"," ");
			tempdata=replacePatternBy("\\[\\[.+?\\]\\]"," ");
			tempdata=replacePatternBy(regexp2," ");
			if(tempdata.contains(System.getProperty("line.separator")))
				System.out.println("line seperator found!");
			if(tempdata.indexOf('\n')!=-1)
				System.out.println("new line found!!");
			tokenize();
			text=false;
		}
		if(qname.equalsIgnoreCase("title"))
		{
			title=false;
			id=true;
		}
		if(qname.equalsIgnoreCase("id"))
		{
			id=false;
		}
		if(qname.equals("file"))
		{
			try {
				write(data);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void characters(char[] chars, int start, int length) throws SAXException 
	{
		if(text)
		{
			sb.append(new String(chars,start,length));
		}
		if(title)
		{
			pageTitle=new String(chars,start,length).trim();
		}
		if(id)
		{
			pageId=new String(chars,start,length).trim();
		}
	}

	private void getCategory()
	{
		Pattern pattern = Pattern.compile("\\[\\[\\s*?(c|C)ategory:.+?\\]\\]");
        Matcher m = pattern.matcher(tempdata);
        int i=0,j=0;
        while(m.find())
        {
        	temp=m.group();
        	temp=temp.substring(temp.indexOf(':')+1,temp.lastIndexOf(']')-1).trim();
        	temp=temp.toLowerCase();
        	temp=pstem.stripAffixes(temp);
        	if(temp.length()>2){
        	if(!sw.isStopWord(temp)){
        	if(data.containsKey(temp))
            {	
        		value=data.get(temp);
        		j=i=value.lastIndexOf("#"+pageId+"#");
        		if(i!=-1)
        		  i=value.indexOf("#", i+1);
        		if(i!=-1)
        		{
        		   if(i!=value.length()-1){
        		     if(!(value.charAt(i+1)=='c' || value.charAt(i+1)=='i'))
        		    setAndIncrementCount(temp,"category",j);}
        		}
        		else
        		{
        			data.put(temp,value.append("#"+pageId+"#1#c"));
        		}
            }
            else
            {
            	data.put(temp,new StringBuffer("#"+pageId+"#1#c"));
            }
        	}
        }
        	
        }
        m.reset();
        tempdata=m.replaceAll(" ");
	}
	
	private void getInfobox()
	{
		Pattern pattern = Pattern.compile("\\{\\{([iI]nfo)?.*?[bB]ox.+?\\}\\}");
        Matcher m = pattern.matcher(tempdata);
        int i=0,j=0;
        while(m.find())
        {
        	temp=m.group();
        	temp=temp.split("\\s+")[1].trim();
        	temp=temp.toLowerCase();
        	temp=pstem.stripAffixes(temp);
        	if(temp.length()>2){
        	if(!sw.isStopWord(temp)){
            if(data.containsKey(temp))
            {
            	value=data.get(temp);
            	j=i=value.lastIndexOf("#"+pageId+"#");
            	if(i!=-1)
            	  i=value.indexOf("#", i+1);
        		if(i!=-1)
        		{
        			if(i!=value.length()-1){
        			if(!(value.charAt(i+1)=='c' || value.charAt(i+1)=='i'))
            	      setAndIncrementCount(temp,"infobox",j);}
        		}
        		else
        		{
        			data.put(temp,value.append("#"+pageId+"#1#i"));
        		}
            }
            else
            {
            	data.put(temp,new StringBuffer("#"+pageId+"#1#i"));
            }
        	}
        	}
        }
        m.reset();
        tempdata=m.replaceAll(" ");
	}
	private void tokenize()
	{
		Pattern pattern = Pattern.compile("\\p{Alpha}+");
        Matcher m = pattern.matcher(tempdata);
        int i=0,j=0;
        while(m.find())
        {
        	temp=m.group().trim();
        	temp=temp.toLowerCase();
        	temp=pstem.stripAffixes(temp);
        	if(temp.length()>2){
        	if(!sw.isStopWord(temp)){
        	if(data.containsKey(temp))
        	{
        		if(temp.equals("philosophi"))
        		  System.out.println("pageid:"+pageId);
        		value=data.get(temp);
        		j=i=value.lastIndexOf("#"+pageId+"#");
        		if(i!=-1)
        		  i=value.indexOf("#", i+1);
        		if(i!=-1)
        		{  
        			if(temp.equals("philosophi"))
        				System.out.println("in tokenize,value:"+value);
        			if(i!=value.length()-1){
        			if(!(value.charAt(i+1)=='c' || value.charAt(i+1)=='i'))
        			   setAndIncrementCount(temp,"count",j);}
        		}
        		else
        		{
        			data.put(temp,value.append("#"+pageId+"#1#"));
        		}
        	}
        	else
        	{
        		data.put(temp,new StringBuffer("#"+pageId+"#1#"));
        	}
        	}
        	}
        }
	}
	private String replacePatternBy(String p,String r)
	{
		Pattern pattern = Pattern.compile(p);
        Matcher m = pattern.matcher(tempdata);
        temp=m.replaceAll(r);
        return temp;
    }
        
	private void write(TreeMap<String,StringBuffer> tm) throws IOException 
	{
		String s;
		for (Map.Entry<String,StringBuffer> entry : data.entrySet())
		{
			s=entry.getKey();
			s+=entry.getValue();
			outputStream.write(s);
			outputStream.write(System.getProperty("line.separator"));
		}
		outputStream.flush();
		outputStream.close();
	}
	
	public void setAndIncrementCount(String key,String type,int index)
	{
		StringBuffer temp=null;
		StringBuffer temp1=null;
		int i=0,j=0,cnt=0,cnt1=0;
		int f1=0,f2=0,f3=0,f4=0;
		try{
		temp=data.get(key);
		System.out.println("checking for"+"#"+pageId+"# in:"+temp+"for word:"+key);
		i=index;
		f1=i;
	    i=temp.indexOf("#",i+1);
	    f2=i;
	    j=temp.indexOf("#",i+1);
	    f3=j;
	    //System.out.println("key:"+key+"#pageid:"+pageId+"#count:"+temp.substring(i+1,j));
	    cnt=Integer.parseInt(temp.substring(i+1,j));
	    cnt1=cnt;
	    cnt=cnt+1;
	    temp1=new StringBuffer(temp);
	    temp.delete(i+1, j);
	    temp.insert(i+1,cnt+"");
	    j=temp.indexOf("#",i+1);
	    f4=j;
		if(type.equals("category"))
		{
			if(temp.indexOf("c",j+1)==-1)
		      temp.insert(j+1, 'c');   
		}
		if(type.equals("infobox"))
		{
			if(temp.indexOf("i",j+1)==-1)
		      temp.insert(j+2, 'i');
		}
		if(type.equals("outlink"))
		{
		    temp.insert(j+3, '1');
		}
		if(type.equals("count"))
		{
			;
		}
		data.put(key, temp);}
		catch(Exception e)
		{
		    System.out.println("key="+key+"\ttype="+type+"\tpageid="+pageId);	
			System.out.println("(before:)f1="+f1+"\tf2="+f2+"\tf3="+f3+"\tvalue="+temp1+"\tcnt="+cnt1);
			System.out.println("(after:)f1="+f1+"\tf2="+f2+"\tf4="+f4+"\tvalue="+temp+"\tcnt="+cnt);
			e.printStackTrace();
			System.exit(1);
		}
	}
	
}


