package sample;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Sample {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new FileReader("C:/Users/Manikanta/Desktop/test/IRE/sample.txt"));
		BufferedWriter primaryIndex=new BufferedWriter(new FileWriter("index.txt"));
		BufferedWriter metaIndex=new BufferedWriter(new FileWriter("meta.txt"));
		String line=null;
		ArrayList<String> l=new ArrayList<String>();
		int linecount=1;
		long offset=0;
		char prev='!',current;
		while((line=br.readLine())!=null)
		{
			current=line.charAt(0);
            if(prev!=current)			
            {    
            	metaIndex.write(offset+"");
            	metaIndex.write(System.getProperty("line.separator"));
            }
            primaryIndex.write(offset+"");
            primaryIndex.write(System.getProperty("line.separator"));
            prev=current;
            linecount++;
            offset+=line.length();
		}
		metaIndex.flush();
		metaIndex.close();
		primaryIndex.flush();
		primaryIndex.close();
	}

}
