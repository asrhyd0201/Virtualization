package sample;

public class Path {
	public static String path;
}
