package sample;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Search {

	private Pattern p1;
	private String query;
	ArrayList<String> title,category,content,infobox,outlinks;//for queries
	private static String path;
	//ArrayList<String> outlinks_title;
	private static ArrayList<Long> metadata_category,metadata_content,metadata_infobox,metadata_outlinks,metadata_title,metadata_page_titles,metadata_redirect;
	private  ArrayList<Long> top10pids;
	//ArrayList<Double> rank_title,rank_category,rank_content,rank_infobox,rank_outlinks;
    //ArrayList<String> index_title,index_category,index_content,index_infobox,index_outlinks;
	private static TreeMap<Long,Double>  rank_title,rank_category,rank_content,rank_infobox,rank_outlinks,rank;
    private StopWordRemoval sw;
    private Porter pstem;
    private static long pageCount;
    private long results,t1,t2;
	//ArrayList<String> metadata_outlinks_title;
    Search() throws IOException
	{
    	t1=System.currentTimeMillis();
    	Search.path="c:/ire/";
    	pageCount=results=0;
    	sw=new StopWordRemoval();
		pstem=new Porter();
		p1 = Pattern.compile("(title:\\p{Alpha}+?\\s+)|(category:\\p{Alpha}+?\\s+)|(outlinks:\\p{Alpha}+?\\s+)|(infobox:\\p{Alpha}+?\\s+)|(content:\\p{Alpha}+?\\s+)");
		title = new ArrayList<String>();
		category = new ArrayList<String>();
		content = new ArrayList<String>();
		infobox = new ArrayList<String>();
		outlinks = new ArrayList<String>();
		//outlinks_title = new ArrayList<String>();
		metadata_title = new ArrayList<Long>();
		metadata_category = new ArrayList<Long>();
		metadata_redirect = new ArrayList<Long>();
		metadata_content = new ArrayList<Long>();
		metadata_infobox = new ArrayList<Long>();
		metadata_outlinks = new ArrayList<Long>();
		metadata_page_titles = new ArrayList<Long>();
		top10pids = new ArrayList<Long>();
		//metadata_outlinks_title = new ArrayList<String>();
		rank_title = new TreeMap<Long,Double>();
		rank_category = new TreeMap<Long,Double>();
		rank_content = new TreeMap<Long,Double>();
		rank_infobox = new TreeMap<Long,Double>();
		rank_outlinks = new TreeMap<Long,Double>();
		rank = new TreeMap<Long,Double>();
		/*index_title = new ArrayList<String>();
		index_category = new ArrayList<String>();
		index_content = new ArrayList<String>();
		index_infobox = new ArrayList<String>();
		index_outlinks = new ArrayList<String>();*/
		loadMetadata();
		do{
	    	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		    System.out.println("Enter your Query('end' to exit):");
		    query=br.readLine().toLowerCase()+" ";
		    if(query.equalsIgnoreCase("end "))
		    	break;
		    parseQueryandRetrieve();
			globalRank();
			getTop10pids();
			getAndDisplayTitles();
		}while(true);
	}
	
   public static void main(String[] args) throws IOException {
	    Path.path="C:/Users/Manikanta/Desktop/test/IRE/";
		new Search();
	}
	
    public void findTitle() throws IOException
	{
		RandomAccessFile raf,raf1 ;
		int len1=0;
		raf= new RandomAccessFile(Search.path+"index_titles.txt", "r");
		raf1=new RandomAccessFile(Search.path+"titles.txt", "r");
		len1=title.size();
		String postingsList;
		/*for(int j=0;j<len1;j++)
		{
			System.out.println("titles:"+title.get(j));
		}*/
		for(int j=0;j<len1;j++)
		{
			postingsList=getPostingsList(raf, raf1, title.get(j),1);
			System.out.println("postinglists:"+postingsList);
			computeFieldWiseRank(postingsList,1);
	    }
		checkRedirect();
	}
	
    public String getPostingsList(RandomAccessFile raf,RandomAccessFile raf1,String temp,int option) throws IOException
	{
		int len=0;
		long offset=0,start=0,end=0,offset1=0,offset2=0;
		boolean flag=false,flag1=false;
		int index;
		String temp1=null,temp2;
		ArrayList<Long> al=null;
		switch(option)
		{
		    case 1:
		    	al=metadata_title;
		    	break;
		    case 2:
		    	al=metadata_content;
		    	break;
		    case 3:
		    	al=metadata_category;
		    	break;
		    case 4:
		    	al=metadata_infobox;
		    	break;
		    case 5:
		    	al=metadata_outlinks;
		    	break;
		    case 6:
		    	al=metadata_redirect;
		    	break;
		    case 7:
		    	al=metadata_page_titles;
		    	break;
		}
		len=al.size();
		//System.out.println("temp="+temp);
		if(option!=6)
		    index=temp.charAt(0)-97;
		else
			index=temp.charAt(0)-48;
		while(true){
		if(index<0)
			return "";
		if(index>len)
		   start=al.get(index-2);
		else
			start=al.get(len-1);
		if(index+1<len)
		  end=al.get(index+1);
		else
		  end=al.get(len-1);
		raf.seek(start);
		offset1=start;
		flag=false;
		while(offset1<end)
		{
			temp1=raf.readLine();
			temp2=temp1.substring(0,temp1.indexOf('#'));
			offset=Long.parseLong(temp1.substring(temp1.indexOf('#')+1));
			if(temp.compareTo(temp2)<0)
			{
				if(offset1==start)
					offset=-1;
				break;
			}
			offset2=offset;
			if(temp.equals(temp2))
			{
				flag=true;
				break;
			}
			offset1+=temp1.length()+2;
		}
		if(offset==-1)
		{	//System.out.println("word:'"+temp+"' not found");
		break;}
		else
		{
			raf1.seek(offset2);
			if(flag)
			{
				temp1=raf1.readLine();
				//System.out.println("word found!!(in index)");
				//System.out.println(temp1);
				break;
			}
			else
			{ 
				temp1=null;
				offset1=offset2;
				while(offset1<=offset)
				{
					temp1=raf1.readLine();
					offset1+=temp1.length()+2;
					if(temp1.substring(0, temp1.indexOf('#')).equals(temp))
					{   flag1=true;break;}
					if(temp1.substring(0, temp1.indexOf('#')).compareTo(temp)>0)
						break;
				}
				if(temp1==null)
				{	//System.out.println("word:'"+temp+"' not found");
				break;}
				else if(flag1)
				{
					//System.out.println("word found!!");
					//System.out.println(temp1);
					break;		
				}
				else
				{
					//System.out.println("word:'"+temp+"' not found");
					flag1=false;
					break;
				}
			}
		}
	    }
		return temp1;
	}
	
	
	public void computeFieldWiseRank(String postingList,int index)
	{
		TreeMap<Long,Double> t=null;
		String[] s;
		double curr_val=0.0;
	   switch(index)
	   {
	      case 1:
	    	  t=rank_title;
	    	  break;
	      case 2:
	    	  t=rank_content;
	    	  break;
	      case 3:
	    	  t=rank_category;
	    	  break;
	      case 4:
	    	  t=rank_infobox;
	    	  break;
	      case 5:
	    	  t=rank_outlinks;
	    	  break;
	   }
	   s=postingList.split("#");
	   for(int i=1;i<s.length;i++)
	   {
		   int pos;
		   long temp=0;
		   if(index!=1){
		   pos=s[i].indexOf(':');
		   temp=Long.parseLong(s[i].substring(0, pos));
		   curr_val=Double.parseDouble(s[i].substring(pos+1));
		   curr_val=curr_val*Math.log10(pageCount/s.length);
		   }
		   else
		   {
			   curr_val=1;
			   temp=Long.parseLong(s[i]);
		   }
		   double prev_val;
		   if(t.containsKey(temp))
		   { 
			   prev_val=t.get(temp);
			   t.put(temp, (prev_val+curr_val)*10);
		   }
		   else
		   {
			   t.put(temp, curr_val);
		   }
	   }
	   System.out.println("t.size="+t.size());
	}
	
	public void loadMetadata() throws IOException
	{
		BufferedReader br=new BufferedReader(new FileReader(Search.path+"metadata_titles.txt"));
		String line;
		while((line=br.readLine())!=null)
		{
			metadata_title.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search.path+"metadata_category.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_category.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search.path+"metadata_infobox.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_infobox.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search.path+"metadata_outlinks.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_outlinks.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search.path+"metadata_data.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_content.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search.path+"metadata_page-titles.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_page_titles.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search.path+"metadata_redirect.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_redirect.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search.path+"noOfDocuments.txt"));
		pageCount=Long.parseLong(br.readLine());
		br.close();
	}
    
    public void parseQueryandRetrieve() throws IOException
    {
	    Matcher m = p1.matcher(query);
    	String t=null,c=null,i=null,d=null,o=null;
    	while(m.find())
    	{
    		t=m.group(1);
    		c=m.group(2);
    		o=m.group(3);
    		i=m.group(4);
    		d=m.group(5);
    		if(t!=null)
    		{
    			t=t.substring(t.indexOf(':')+1).trim().toLowerCase();
    			t=pstem.stripAffixes(t);
    	    	if(t.length()>2){
    	    	if(!sw.isStopWord(t))
    	    	{
    			title.add(t);}}
    		}
    		if(c!=null)
    		{
    			c=c.substring(c.indexOf(':')+1).trim().toLowerCase();
    			c=pstem.stripAffixes(c);
    	    	if(c.length()>2){
    	    	if(!sw.isStopWord(c))
    	    	{
    			category.add(c);}}
    		}
    		if(o!=null)
    		{
    			o=o.substring(o.indexOf(':')+1).trim().toLowerCase();
    			o=pstem.stripAffixes(o);
    	    	if(o.length()>2){
    	    	if(!sw.isStopWord(o))
    	    	{
    			   outlinks.add(o);}}
    		}
    		if(i!=null)
    		{
    			i=i.substring(i.indexOf(':')+1).trim().toLowerCase();
    			i=pstem.stripAffixes(i);
    	    	if(i.length()>2){
    	    	if(!sw.isStopWord(i))
    	    	{
    			   infobox.add(i);}}
    		}
    		if(d!=null)
    		{
    			d=d.substring(d.indexOf(':')+1).trim().toLowerCase();
    			d=pstem.stripAffixes(d);
    	    	if(d.length()>2){
    	    	if(!sw.isStopWord(d))
    	    	{
    			   content.add(d);}}
    		}
    	}
    	try {
    		NewThread obj1=null,obj2=null,obj3=null,obj4=null,obj5=null;
    		if(title.size()>=1)
    		{
			    obj1=new NewThread("1",this);
    		}
    		if(category.size()>=1)
    		{
			    obj2=new NewThread("2",this);
    		}
    		if(content.size()>=1)
    		{
			    obj3=new NewThread("3",this);
    		}
    		if(infobox.size()>=1)
    		{
			    obj4=new NewThread("4",this);
    		}
    		if(outlinks.size()>=1)
    		{
			   obj5=new NewThread("5",this);
    		}
			if(title.size()>=1)
			{
			   obj1.t.join();
			}
			if(category.size()>=1)
			{
			   obj2.t.join();
			}
			if(content.size()>=1)
			{
			   obj3.t.join();
			}
			if(infobox.size()>=1)
			{
			   obj4.t.join();
			}
			if(outlinks.size()>=1)
			{
			   obj5.t.join();
			}
    		/*findTitle();
    		findCategory();
    		findContent();
    		findInfobox();
    		findOutlinks();*/
		} catch (Exception e) {
			e.printStackTrace();
		}
		title.clear();
		category.clear();
		outlinks.clear();
		infobox.clear();
		content.clear();
      
   }
    
    public void findContent() throws IOException
    {
    	RandomAccessFile raf,raf1 ;
		int len1=0;
		raf= new RandomAccessFile(Search.path+"index_data.txt", "r");
		raf1=new RandomAccessFile(Search.path+"data.txt", "r");
		len1=content.size();
		String postingsList;
		for(int j=0;j<len1;j++)
		{
			postingsList=getPostingsList(raf, raf1, content.get(j),2);
			computeFieldWiseRank(postingsList,2);
			
	    }

    }
    
    public void findCategory() throws IOException
    {
    	RandomAccessFile raf,raf1 ;
		int len1=0;
		raf= new RandomAccessFile(Search.path+"index_category.txt", "r");
		raf1=new RandomAccessFile(Search.path+"category.txt", "r");
		len1=category.size();
		String postingsList;
		for(int j=0;j<len1;j++)
		{
			postingsList=getPostingsList(raf, raf1, category.get(j),3);
			computeFieldWiseRank(postingsList,3);
			
	    }
    }
    
    public void findInfobox() throws IOException
    {
    	RandomAccessFile raf,raf1 ;
		int len1=0;
		raf= new RandomAccessFile(Search.path+"index_infobox.txt", "r");
		raf1=new RandomAccessFile(Search.path+"infobox.txt", "r");
		len1=infobox.size();
		String postingsList;
		for(int j=0;j<len1;j++)
		{
			postingsList=getPostingsList(raf, raf1, infobox.get(j),4);
			computeFieldWiseRank(postingsList,4);
			
	    }

    }

    public void findOutlinks() throws IOException
    {
    	RandomAccessFile raf,raf1 ;
		int len1=0;
		raf= new RandomAccessFile(Search.path+"index_outlinks.txt", "r");
		raf1=new RandomAccessFile(Search.path+"outlinks.txt", "r");
		len1=outlinks.size();
		String postingsList;
		for(int j=0;j<len1;j++)
		{
			postingsList=getPostingsList(raf, raf1, outlinks.get(j),5);
			computeFieldWiseRank(postingsList,5);
			
	    }

    }
    
    public void globalRank()
    {
    	TreeMap<Long,Double> t=null;
    	double curr_val=0.0;
    	for(int i=1;i<6;i++){
    		switch(i)
    		   {
    		      case 1:
    		    	  t=rank_title;
    		    	  curr_val=1;
    		    	  break;
    		      case 2:
    		    	  t=rank_content;
    		    	  curr_val=0.1;
    		    	  break;
    		      case 3:
    		    	  t=rank_category;
    		    	  curr_val=0.5;
    		    	  break;
    		      case 4:
    		    	  t=rank_infobox;
    		    	  curr_val=0.75;
    		    	  break;
    		      case 5:
    		    	  t=rank_outlinks;
    		    	  curr_val=0.25;
    		    	  break;
    		   }
    	Set<Map.Entry<Long,Double>> set = t.entrySet();
		Iterator<Map.Entry<Long,Double>> iterator = set.iterator();
        
		Long key;
		Double value,value1;
		while(iterator.hasNext()) {
			Map.Entry<Long,Double> entry = (Map.Entry<Long,Double>)iterator.next();
			key=entry.getKey();
			value=entry.getValue();
			if(rank.containsKey(key))
			{
				value1=rank.get(key);
				rank.put(key, (value1+curr_val*value)*100);
			}
			else
			{
				rank.put(key, value);
				results++;
			}
		}
    	}
    }
    
    
    public void getTop10pids()
    {
    	TreeMap<Long,Double> tm;
    	tm=new MapValueSort().sortOnValue(rank);
    	int i=0;
    	double x;
    	boolean flag=false;
    	Set<Map.Entry<Long,Double>> set = tm.entrySet();
		Iterator<Map.Entry<Long,Double>> iterator = set.iterator();
    	while(iterator.hasNext()) {
			Map.Entry<Long,Double> entry = (Map.Entry<Long,Double>)iterator.next();
			x=entry.getValue();
			Set<Map.Entry<Long,Double>> set1 = rank.entrySet();
			Iterator<Map.Entry<Long,Double>> iterator1 = set1.iterator();
			double y;
	    	while(iterator1.hasNext()) {
				Map.Entry<Long,Double> entry1 = (Map.Entry<Long,Double>)iterator1.next();
				y=entry1.getValue();
				if(x==y)
				{
					top10pids.add(entry1.getKey());
					i++;
					if(i==10)
					{
						flag=true;
						break;
					}
				}
	    	}
	    	if(flag)
	    		break;
    	}
    }
    
    public void checkRedirect() throws IOException
    {
    	TreeMap<Long,Double> tm;
    	tm=new MapValueSort().sortOnValue(rank_title);
    	ArrayList<Long> al=new ArrayList<Long>();
    	int i=0;
    	double x;
    	boolean flag=false;
    	Set<Map.Entry<Long,Double>> set = tm.entrySet();
		Iterator<Map.Entry<Long,Double>> iterator = set.iterator();
    	while(iterator.hasNext()) {
			Map.Entry<Long,Double> entry = (Map.Entry<Long,Double>)iterator.next();
			x=entry.getValue();
			Set<Map.Entry<Long,Double>> set1 = rank_title.entrySet();
			Iterator<Map.Entry<Long,Double>> iterator1 = set1.iterator();
			double y;
	    	while(iterator1.hasNext()) {
				Map.Entry<Long,Double> entry1 = (Map.Entry<Long,Double>)iterator1.next();
				y=entry1.getValue();
				if(x==y)
				{
					al.add(entry1.getKey());
					i++;
					if(i==10)
					{
						flag=true;
						break;
					}
				}
	    	}
	    	if(flag)
	    		break;
    	}
    	for(i=0;i<al.size();i++)
    	{
    		RandomAccessFile raf,raf1 ;
    		raf= new RandomAccessFile(Search.path+"index_redirect.txt", "r");
    		raf1=new RandomAccessFile(Search.path+"redirect.txt", "r");
    		String postingsList;
    		postingsList=getPostingsList(raf, raf1, al.get(i)+"",6);
    		if(postingsList!=null){
    		Pattern p=Pattern.compile("\\p{Alpha}+");
    		Matcher m=p.matcher(postingsList);
    		while(m.find())
    		{
    			String temp=m.group();
    			temp=m.group().trim();
	        	temp=temp.toLowerCase();
	        	temp=pstem.stripAffixes(temp);
	        	if(temp.length()>2){
	        	if(!sw.isStopWord(temp))
	        	{
    			RandomAccessFile raf2,raf3 ;
        		raf2= new RandomAccessFile(Search.path+"index_titles.txt", "r");
        		raf3=new RandomAccessFile(Search.path+"titles.txt", "r");
    			String s=getPostingsList(raf2, raf3, temp,1);
    		   computeFieldWiseRank(s,1);
    		}}}
    		}
    	}
    }
    
    public void getAndDisplayTitles() throws IOException
    {
    	t2=System.currentTimeMillis();
    	System.out.println(results+" found in "+(t2-t1));
    	for(int i=0;i<top10pids.size();i++)
    	{
    		RandomAccessFile raf,raf1 ;
    		raf= new RandomAccessFile(Search.path+"index_page-titles.txt", "r");
    		raf1=new RandomAccessFile(Search.path+"page-titles.txt", "r");
    		String postingsList;
    		postingsList=getPostingsList(raf, raf1, top10pids.get(i)+"",7);
    		System.out.println(postingsList);
    	}
    }
}


//Create multiple threads.
class NewThread implements Runnable {
  Thread t;
  String name;
  Search s;  
  NewThread(String threadname,Search obj) throws IOException {
    name = threadname;
    t = new Thread(this, name);
    s=obj;
    t.start(); // Start the thread
  }

  // This is the entry point for thread.
  public void run() {
    try {
     
    	int index;
    	index=Integer.parseInt(t.getName());
    	switch(index)
    	{
    	    case 1:
    	    	s.findTitle();
    	    	break;
    	    case 2:
    	    	s.findCategory();
    	    	break;
    	    case 3:
    	    	s.findContent();
    	    	break;
    	    case 4:
    	    	s.findInfobox();
    	    	break;
    	    case 5:
    	    	s.findOutlinks();
    	    	break;
    	}
    } catch (Exception e) {
      System.out.println(name + "Interrupted");
      e.printStackTrace();
    }
  }
}