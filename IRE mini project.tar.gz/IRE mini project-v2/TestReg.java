package sample;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestReg {

	public static void main(String[] args) throws IOException 
	{
		Pattern p=Pattern.compile("(\\[\\[(.+?)\\|(.+?)\\]\\]\\s+)|(\\[\\[(.+?)\\]\\]\\s+)");
		//Pattern p=Pattern.compile("(\\[\\[[cC]ategory:(.+?)\\]\\])|(\\{\\{[iI]nfo[bB]ox\\s+(.+?)\\|.+\\}\\}\\s+)");
		String temp,inp="[[abc|def]]  [[ghi]]  [[lmnop:#@$@$]] [[efgh]] [[qrst|uvwxy]] ";
		//String temp,inp="[category:abcd]";
		Matcher m=p.matcher(inp);
        while(m.find())
        {
        	//System.out.println("pattern matched");
        	temp=m.group(1);
        	if(temp!=null)
        	{
        		String temp1=m.group(2);
        		String temp2=m.group(3);
        		System.out.println("(in first if)temp1="+temp1+"\ttemp2:"+temp2);
        	}
        	else
        	{
        		temp=m.group(4);
        		if(temp!=null)
        		{
        			String temp1=m.group(5);
        			if(temp1.indexOf(':')==-1)
        			  System.out.println("(in second if)temp1="+temp1);
        		}
        	}
        		
        }
        m.reset();
        inp=m.replaceAll(" ");
        System.out.println("inp="+inp+"::");
	}

}
