package sample;

import java.io.*;
import java.util.zip.*;

public class Zip {
   static final int BUFFER = 2048;
   Zip(String target) {
      try {
         BufferedInputStream origin = null;
         new File(target+"index").mkdir();
         FileOutputStream dest = new 
           FileOutputStream(target+"index/"+"index.zip");
         ZipOutputStream out = new ZipOutputStream(new 
           BufferedOutputStream(dest));
         //out.setMethod(ZipOutputStream.DEFLATED);
         byte data[] = new byte[BUFFER];
         String[] files=new File(target).list();
         // get a list of files from current directory
         //File f = new File(".");
         //String files[] = {"data.txt","category.txt","infobox.txt","outlinks.txt","outlinks_title.txt","titles.txt"};

         for (int i=0; i<files.length; i++) {
            //System.out.println("Adding: "+files[i]);
        	 File f=new File(target+files[i]);
        	 if(!f.isDirectory()){
            FileInputStream fi = new 
              FileInputStream(target+files[i]);
            origin = new 
              BufferedInputStream(fi, BUFFER);
            ZipEntry entry = new ZipEntry(files[i]);
            out.putNextEntry(entry);
            int count;
            while((count = origin.read(data, 0, 
              BUFFER)) != -1) {
               out.write(data, 0, count);
            }
            origin.close();
            }
         }
         for(String f:new File(target).list())
         {
        	File file=new File(target+f);
        	if(!file.isDirectory())
        		file.delete();
         }
         out.close();
      } catch(Exception e) {
         e.printStackTrace();
      }
   }
}

