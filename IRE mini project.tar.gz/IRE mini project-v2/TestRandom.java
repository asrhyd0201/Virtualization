package sample;

import java.io.IOException;
import java.io.RandomAccessFile;

public class TestRandom {

	public static void main(String[] args) throws IOException {
		RandomAccessFile raf= new RandomAccessFile("test.txt", "r");
		System.out.println(raf.readLine()+",");
		System.out.println(raf.getFilePointer());
		System.out.println(raf.readLine()+",");
		System.out.println(raf.getFilePointer());
		System.out.println(raf.readLine()+",");
		System.out.println(raf.getFilePointer());
	}

}
