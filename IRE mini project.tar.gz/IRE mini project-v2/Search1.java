package sample;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Search1 {

	private Pattern p1;
	private String query;
	ArrayList<String> title,category,content,infobox,outlinks;//for queries
	private static String path,indexPath;
	//ArrayList<String> outlinks_title;
	ArrayList<Long> metadata_category,metadata_content,metadata_infobox,metadata_outlinks,metadata_title,metadata_page_titles,metadata_redirect,top10pageids;
	private TreeMap<Long,Double>  rank_title,rank_category,rank_content,rank_infobox,rank_outlinks,rank;
    //ArrayList<String> index_title,index_category,index_content,index_infobox,index_outlinks;
    private StopWordRemoval sw;
    private Porter pstem;
    private long pageCount;
    private BufferedWriter bw; 
    private long results,t1,t2;
	//ArrayList<String> metadata_outlinks_title;
    Search1(String p) throws IOException
	{
    	path=p;
    	pageCount=results=0;
    	//bw=new BufferedWriter(new FileWriter("c:/ire1/log.tx"));
    	sw=new StopWordRemoval();
		pstem=new Porter();
    	indexPath=p;
    	/*String path=p+"index/index.zip";
		String temp=path.substring(0, path.lastIndexOf('/'));
		temp=temp.substring(0,temp.lastIndexOf('/')+1);
		new UnZip(path,temp);*/
		p1 = Pattern.compile("(title:.+?\\s+)|(category:.+?\\s+)|(outlinks:.+?\\s+)|(infobox:.+?\\s+)|(content:.+?\\s+)");
		title = new ArrayList<String>();
		category = new ArrayList<String>();
		content = new ArrayList<String>();
		infobox = new ArrayList<String>();
		outlinks = new ArrayList<String>();
		//outlinks_title = new ArrayList<String>();
		metadata_title = new ArrayList<Long>();
		metadata_category = new ArrayList<Long>();
		metadata_content = new ArrayList<Long>();
		metadata_infobox = new ArrayList<Long>();
		metadata_outlinks = new ArrayList<Long>();
		metadata_page_titles = new ArrayList<Long>();
		//metadata_redirect = new ArrayList<Long>();
		top10pageids = new ArrayList<Long>();
		//metadata_outlinks_title = new ArrayList<String>();
		rank_title = new TreeMap<Long,Double>();
		rank_category = new TreeMap<Long,Double>();
		rank_content = new TreeMap<Long,Double>();
		rank_infobox = new TreeMap<Long,Double>();
		rank_outlinks = new TreeMap<Long,Double>();
		rank = new TreeMap<Long,Double>();
		
		/*index_title = new ArrayList<String>();
		index_category = new ArrayList<String>();
		index_content = new ArrayList<String>();
		index_infobox = new ArrayList<String>();
		index_outlinks = new ArrayList<String>();*/
		loadMetadata();
		do{
	    	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		    System.out.println("Enter your Query('end' to exit):");
		    t1=System.currentTimeMillis();
		    query=br.readLine().toLowerCase()+" ";
		    if(query.equalsIgnoreCase("end "))
		    	break;
		    parseQueryandRetrieve(query);
		    globalRank();
		    gettop10pids();
		    getPageTitles();
		    rank_category.clear();
		    rank_content.clear();
		    rank_infobox.clear();
		    rank_outlinks.clear();
		    rank_title.clear();
		    rank.clear();
		    top10pageids.clear();
		    results=0;
		}while(true);
		//bw.flush();
		//bw.close();
	}
	public static void main(String[] args) throws IOException {
	    //Path.path="C:/Users/Manikanta/Desktop/test/IRE/";
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter source directory:");
		new Search1(br.readLine()+"/");
	}
	public void findTitle() throws IOException
	{
		RandomAccessFile raf,raf1 ;
		int len=0,len1=0;
		long offset=0,start=0,end=0,offset1=0,offset2=0;
		boolean flag=false,flag1=false;
		int index;
		String temp,temp1=null,temp2;
		raf= new RandomAccessFile(Search1.indexPath+"index_titles.txt", "r");
		raf1=new RandomAccessFile(Search1.path+"titles.txt", "r");
		len=metadata_title.size();
		len1=title.size();
		for(int j=0;j<len1;j++)
		{
			temp=title.get(j);
			index=temp.charAt(0)-97;
			while(true && index>=0){
			if(index<len)
			  start=metadata_title.get(index);
			else
				start=metadata_title.get(len-2);	
			if(index+1<len)
			  end=metadata_title.get(index+1);
			else
			  end=metadata_title.get(len-1);
			raf.seek(start);
			offset1=start;
			flag=false;
			while(offset1<=end)
			{
				temp1=raf.readLine();
				temp2=temp1.substring(0,temp1.indexOf('#'));
				offset=Long.parseLong(temp1.substring(temp1.indexOf('#')+1));
				if(temp.compareTo(temp2)<0)
				{
					if(offset1==start)
						offset=-1;
					break;
				}
				offset2=offset;
				if(temp.equals(temp2))
				{
					flag=true;
					break;
				}
				offset1+=temp1.length()+2;
			}
			if(offset==-1)
			{	
				//writeLog("word:'"+temp+"' not found");
				break;
			}
			else
			{
				raf1.seek(offset2);
				if(flag)
				{
					temp1=raf1.readLine();
					//writeLog("word found!!(in index)");
					//writeLog(temp1);
					break;
				}
				else
				{ 
					temp1=null;
					offset1=offset2;
					while(offset1<=offset)
					{
						temp1=raf1.readLine();
						offset1+=temp1.length()+2;
						if(temp1.substring(0, temp1.indexOf('#')).equals(temp))
						{   flag1=true;break;}
						if(temp1.substring(0, temp1.indexOf('#')).compareTo(temp)>0)
							break;
					}
					if(temp1==null)
					{	
						//writeLog("word:'"+temp+"' not found");
						break;
					}
					else if(flag1)
					{
						//writeLog("word found!!");
						//writeLog(temp1);
						break;		
					}
					else
					{
						//writeLog("word:'"+temp+"' not found");
						flag1=false;
						break;
					}
				}
			}
		    }
	        if(temp1!=null)
	        {
	        	/*synchronized(this)
    			{
	        		writeLog("");
	        	writeLog("******For Title*****");
	        	writeLog("");
	        	writeLog("");
	        	writeLog("");}*/
	        	String[] temp4=temp1.substring(temp1.indexOf('#')+1).split("#");
	        	for(String s:temp4)
	        	{
	        		long pid=Long.parseLong(s);
	        		double curr_val=50,prev_val;
	        		if(rank_title.containsKey(new Long(pid)))
	        		{
	        	       prev_val=rank_title.get(pid).doubleValue();
	        	       rank_title.put(new Long(pid), new Double((curr_val+prev_val)*10));
	        	       /*synchronized(this)
	        			{
	        	    	   writeLog("");
	        	    	   writeLog("****updated category*****");
	        	    	   writeLog("");
	       	        	    writeLog("");
	        				print(rank_title);
	        			}*/
	        		}
	        		else
	        			rank_title.put(new Long(pid),new Double(curr_val));
	        	}
	        }
	   }
		/*synchronized(this)
		{
			print(rank_title);
			writeLog("");
			writeLog("******End of Title*****");	
			writeLog("");
			writeLog("");
		}*/
	}
	
	public void loadMetadata() throws IOException
	{
		BufferedReader br=new BufferedReader(new FileReader(Search1.indexPath+"metadata_titles.txt"));
		String line;
		while((line=br.readLine())!=null)
		{
			metadata_title.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search1.indexPath+"metadata_category.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_category.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search1.indexPath+"metadata_infobox.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_infobox.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search1.indexPath+"metadata_outlinks.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_outlinks.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search1.indexPath+"metadata_data.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_content.add(Long.parseLong(line));
		}
		br.close();
		br=new BufferedReader(new FileReader(Search1.indexPath+"metadata_page-titles.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_page_titles.add(Long.parseLong(line));
		}
		br.close();
		/*br=new BufferedReader(new FileReader(Search1.path+"metadata_redirect.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_redirect.add(Long.parseLong(line));
		}*/
		br.close();
		br=new BufferedReader(new FileReader(Search1.path+"noOfDocuments.txt"));
		pageCount=Long.parseLong(br.readLine());
		br.close();
		/*br=new BufferedReader(new FileReader(path+"metadata_outlinks_title.txt"));
		while((line=br.readLine())!=null)
		{
			metadata_outlinks_title.add(line);
		}
		br.close();*/
	}
    public void parseQueryandRetrieve(String query) throws IOException
    {
    	
	    Matcher m = p1.matcher(query);
    	String t=null,c=null,i=null,d=null,o=null;
    	while(m.find())
    	{
    		t=m.group(1);
    		c=m.group(2);
    		o=m.group(3);
    		i=m.group(4);
    		d=m.group(5);
    		if(t!=null)
    		{
    			t=t.substring(t.indexOf(':')+1).trim();
    			t=pstem.stripAffixes(t);
    	    	if(t.length()>2){
    	    	if(!sw.isStopWord(t))
    	    	{
    			title.add(t);}}
    		}
    		if(c!=null)
    		{
    			c=c.substring(c.indexOf(':')+1).trim();
    			c=pstem.stripAffixes(c);
    	    	if(c.length()>2){
    	    	if(!sw.isStopWord(c))
    	    	{
    			category.add(c);}}
    		}
    		if(o!=null)
    		{
    			o=o.substring(o.indexOf(':')+1).trim();
    			o=pstem.stripAffixes(o);
    	    	if(o.length()>2){
    	    	if(!sw.isStopWord(o))
    	    	{
    			   outlinks.add(o);}}
    		}
    		if(i!=null)
    		{
    			i=i.substring(i.indexOf(':')+1).trim();
    			i=pstem.stripAffixes(i);
    	    	if(i.length()>2){
    	    	if(!sw.isStopWord(i))
    	    	{
    			   infobox.add(i);}}
    		}
    		if(d!=null)
    		{
    			d=d.substring(d.indexOf(':')+1).trim();
    			d=pstem.stripAffixes(d);
    	    	if(d.length()>2){
    	    	if(!sw.isStopWord(d))
    	    	{
    			   content.add(d);}}
    		}
    	}
    	try {
    		NewThreadv1 obj1=null,obj2=null,obj3=null,obj4=null,obj5=null;
    		if(title.size()>=1)
    		{
			    obj1=new NewThreadv1("1",this);
    		}
    		if(category.size()>=1)
    		{
			    obj2=new NewThreadv1("2",this);
    		}
    		if(content.size()>=1)
    		{
			    obj3=new NewThreadv1("3",this);
    		}
    		if(infobox.size()>=1)
    		{
			    obj4=new NewThreadv1("4",this);
    		}
    		if(outlinks.size()>=1)
    		{
			   obj5=new NewThreadv1("5",this);
    		}
			if(title.size()>=1)
			{
			   obj1.t.join();
			}
			if(category.size()>=1)
			{
			   obj2.t.join();
			}
			if(content.size()>=1)
			{
			   obj3.t.join();
			}
			if(infobox.size()>=1)
			{
			   obj4.t.join();
			}
			if(outlinks.size()>=1)
			{
			   obj5.t.join();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		title.clear();
		category.clear();
		outlinks.clear();
		infobox.clear();
		content.clear();
		
   }
    
    public boolean compute(int index,int i)
    {
    	return true;
    }
    
    public void findContent() throws IOException
    {
    	RandomAccessFile raf,raf1 ;
		int len=0,len1=0;
		long offset=0,start=0,end=0,offset1=0,offset2=0;
		boolean flag=false,flag1=false;
		int index;
		String temp,temp1=null,temp2;
		raf= new RandomAccessFile(Search1.indexPath+"index_data.txt", "r");
		raf1=new RandomAccessFile(Search1.path+"data.txt", "r");
		len=metadata_content.size();
		len1=content.size();
		for(int j=0;j<len1;j++)
		{
			temp=content.get(j);
			index=temp.charAt(0)-97;
			while(true && index>=0){
			if(index<len)
			  start=metadata_content.get(index);
			else
				start=metadata_content.get(len-2);
			if(index+1<len)
			  end=metadata_content.get(index+1);
			else
			  end=metadata_content.get(len-1);
			raf.seek(start);
			offset1=start;
			flag=false;
			while(offset1<=end)
			{
				temp1=raf.readLine();
				temp2=temp1.substring(0,temp1.indexOf('#'));
				offset=Long.parseLong(temp1.substring(temp1.indexOf('#')+1));
				if(temp.compareTo(temp2)<0)
				{
					if(offset1==start)
						offset=-1;
					break;
				}
				offset2=offset;
				if(temp.equals(temp2))
				{
					flag=true;
					break;
				}
				offset1+=temp1.length()+2;
			}
			if(offset==-1)
			{	
				//writeLog("word:'"+temp+"' not found");
				break;
			}
			else
			{
				raf1.seek(offset2);
				if(flag)
				{
					temp1=raf1.readLine();
					//writeLog("word found!!(in index)");
					//writeLog(temp1);
					break;
				}
				else
				{ 
					temp1=null;
					offset1=offset2;
					while(offset1<=offset)
					{
						temp1=raf1.readLine();
						offset1+=temp1.length()+2;
						if(temp1.substring(0, temp1.indexOf('#')).equals(temp))
						{   flag1=true;break;}
						if(temp1.substring(0, temp1.indexOf('#')).compareTo(temp)>0)
							break;
					}
					if(temp1==null)
					{	
						//writeLog("word:'"+temp+"' not found");
						break;
					}
					else if(flag1)
					{
						//writeLog("word found!!");
						//writeLog(temp1);
						break;		
					}
					else
					{
						//writeLog("word:'"+temp+"' not found");
						flag1=false;
						break;
					}
				}
			}
		    }
			if(temp1!=null)
	        {
	        	String[] temp4=temp1.substring(temp1.indexOf('#')+1).split("#");
	        	int len2=temp4.length;
	        	for(String s:temp4)
	        	{
	        		long pid=Long.parseLong(s.substring(0,s.indexOf(':')));
	        		double curr_val,prev_val;
	        		curr_val=Double.parseDouble(s.substring(s.indexOf(':')+1));
	        		curr_val=curr_val*Math.log10(pageCount/len2);
	        		if(rank_content.containsKey(new Long(pid)))
	        		{
	        	       prev_val=rank_content.get(pid).doubleValue();
	        	       rank_content.put(new Long(pid), new Double((curr_val+prev_val)*10));
	        		}
	        		else
	        			rank_content.put(new Long(pid),new Double(curr_val));
	        	}
	        }
	        //compute();
	   }
		/*synchronized(this)
		{
			print(rank_content);
		}*/

    }
    public void findCategory() throws IOException
    {
    	RandomAccessFile raf,raf1 ;
		int len=0,len1=0;
		long offset=0,start=0,end=0,offset1=0,offset2=0;
		boolean flag=false,flag1=false;
		int index;
		String temp,temp1=null,temp2;
		raf= new RandomAccessFile(Search1.indexPath+"index_category.txt", "r");
		raf1=new RandomAccessFile(Search1.path+"category.txt", "r");
		len=metadata_category.size();
		len1=category.size();
		for(int j=0;j<len1;j++)
		{
			temp=category.get(j);
			index=temp.charAt(0)-97;
			while(true && index>=0){
			if(index<len)
			  start=metadata_category.get(index);
			else
				start=metadata_category.get(len-2);	
			if(index+1<len)
			  end=metadata_category.get(index+1);
			else
			  end=metadata_category.get(len-1);
			raf.seek(start);
			offset1=start;
			flag=false;
			while(offset1<=end)
			{
				temp1=raf.readLine();
				temp2=temp1.substring(0,temp1.indexOf('#'));
				offset=Long.parseLong(temp1.substring(temp1.indexOf('#')+1));
				if(temp.compareTo(temp2)<0)
				{
					if(offset1==start)
						offset=-1;
					break;
				}
				offset2=offset;
				if(temp.equals(temp2))
				{
					flag=true;
					break;
				}
				offset1+=temp1.length()+2;
			}
			if(offset==-1)
			{	
				//writeLog("word:'"+temp+"' not found");
				break;
			}
			else
			{
				raf1.seek(offset2);
				if(flag)
				{
					temp1=raf1.readLine();
					//writeLog("word found!!");
					//writeLog(temp1);
					break;
				}
				else
				{ 
					temp1=null;
					offset1=offset2;
					while(offset1<=offset)
					{
						temp1=raf1.readLine();
						offset1+=temp1.length()+2;
						if(temp1.substring(0, temp1.indexOf('#')).equals(temp))
						{   flag1=true;break;}
						if(temp1.substring(0, temp1.indexOf('#')).compareTo(temp)>0)
							break;
					}
					if(temp1==null)
					{	
						//writeLog("word:'"+temp+"' not found");
						break;
					}
					else if(flag1)
					{
						//writeLog("word found!!");
						//writeLog(temp1);
						break;		
					}
					else
					{
						//writeLog("word:'"+temp+"' not found");
						flag1=false;
						break;
					}
				}
			}
		    }
			if(temp1!=null)
	        {
				/*synchronized(this)
    			{
					writeLog("");
				writeLog("******For Category*****");
				writeLog("");
				writeLog("");
				writeLog("");
    			}*/
	        	String[] temp4=temp1.substring(temp1.indexOf('#')+1).split("#");
	        	int len2=temp4.length;
	        	for(String s:temp4)
	        	{
	        		long pid=Long.parseLong(s.substring(0,s.indexOf(':')));
	        		double curr_val,prev_val;
	        		curr_val=Double.parseDouble(s.substring(s.indexOf(':')+1));
	        		curr_val=curr_val*Math.log10(pageCount/len2);
	        		if(rank_category.containsKey(new Long(pid)))
	        		{
	        	       prev_val=rank_category.get(pid).doubleValue();
	        	       rank_category.put(new Long(pid), new Double((curr_val+prev_val)*10));
	        	       /*synchronized(this)
	        			{writeLog("");
	        	    	   writeLog("****updated category***");
	        			    writeLog("");
	        			    writeLog("");
	        				print(rank_category);
	        			}*/
	        		}
	        		else
	        			rank_category.put(new Long(pid),new Double(curr_val));
	        	}
	        }
	        //compute();
	   }
		/*synchronized(this)
		{
			print(rank_category);
			writeLog("");
			writeLog("*******end of category***");
			writeLog("");
			writeLog("");
		}*/
        
    }
    
    public void findInfobox() throws IOException
    {
    	RandomAccessFile raf,raf1 ;
		int len=0,len1=0;
		long offset=0,start=0,end=0,offset1=0,offset2=0;
		boolean flag=false,flag1=false;
		int index;
		String temp,temp1=null,temp2;
		raf= new RandomAccessFile(Search1.indexPath+"index_infobox.txt", "r");
		raf1=new RandomAccessFile(Search1.path+"infobox.txt", "r");
		len=metadata_infobox.size();
		len1=infobox.size();
		for(int j=0;j<len1;j++)
		{
			temp=infobox.get(j);
			index=temp.charAt(0)-97;
			while(true && index>=0){
			if(index<len)
			  start=metadata_infobox.get(index);
			else
				start=metadata_infobox.get(len-2);
			if(index+1<len)
			  end=metadata_infobox.get(index+1);
			else
			  end=metadata_infobox.get(len-1);
			raf.seek(start);
			offset1=start;
			flag=false;
			while(offset1<=end)
			{
				temp1=raf.readLine();
				temp2=temp1.substring(0,temp1.indexOf('#'));
				offset=Long.parseLong(temp1.substring(temp1.indexOf('#')+1));
				if(temp.compareTo(temp2)<0)
				{
					if(offset1==start)
						offset=-1;
					break;
				}
				offset2=offset;
				if(temp.equals(temp2))
				{
					flag=true;
					break;
				}
				offset1+=temp1.length()+2;
			}
			if(offset==-1)
			{	
				//writeLog("word:'"+temp+"' not found(1st while)");
			    break;
			}
			else
			{
				raf1.seek(offset2);
				if(flag)
				{
					temp1=raf1.readLine();
					//writeLog("word found!!(in index)");
					//writeLog(temp1);
					break;
				}
				else
				{ 
					temp1=null;
					offset1=offset2;
					while(offset1<=offset)
					{
						temp1=raf1.readLine();
						offset1+=temp1.length()+2;
						if(temp1.substring(0, temp1.indexOf('#')).equals(temp))
						{   flag1=true;break;}
						if(temp1.substring(0, temp1.indexOf('#')).compareTo(temp)>0)
							break;
					}
					if(temp1==null)
					{	
						//writeLog("word:'"+temp+"' not found(2nd)");
						break;
					}
					else if(flag1)
					{
						//writeLog("word found!!");
						//writeLog(temp1);
						break;		
					}
					else
					{
						//writeLog("word:'"+temp+"' not found(3rd)");
						flag1=false;
						break;
					}
				}
			}
		    }
			if(temp1!=null)
	        {
	        	String[] temp4=temp1.substring(temp1.indexOf('#')+1).split("#");
	        	int len2=temp4.length;
	        	for(String s:temp4)
	        	{
	        		long pid=Long.parseLong(s.substring(0,s.indexOf(':')));
	        		double curr_val,prev_val;
	        		curr_val=Double.parseDouble(s.substring(s.indexOf(':')+1));
	        		curr_val=curr_val*Math.log10(pageCount/len2);
	        		if(rank_infobox.containsKey(new Long(pid)))
	        		{
	        	       prev_val=rank_infobox.get(pid).doubleValue();
	        	       rank_infobox.put(new Long(pid), new Double((curr_val+prev_val)*10));
	        		}
	        		else
	        			rank_infobox.put(new Long(pid),new Double(curr_val));
	        	}
	        }
	        //compute();
	   }
		/*synchronized(this)
		{
			print(rank_infobox);
		}*/

    }

    public void findOutlinks() throws IOException
    {
    	RandomAccessFile raf,raf1 ;
		int len=0,len1=0;
		long offset=0,start=0,end=0,offset1=0,offset2=0;
		boolean flag=false,flag1=false;
		int index;
		String temp,temp1=null,temp2;
		raf= new RandomAccessFile(Search1.indexPath+"index_outlinks.txt", "r");
		raf1=new RandomAccessFile(Search1.path+"outlinks.txt", "r");
		len=metadata_outlinks.size();
		len1=outlinks.size();
		for(int j=0;j<len1;j++)
		{
			temp=outlinks.get(j);
			index=temp.charAt(0)-97;
			while(true && index>=0){
			if(index<len)
				start=metadata_outlinks.get(index);
			else
				start=metadata_outlinks.get(len-2);
			if(index+1<len)
			  end=metadata_outlinks.get(index+1);
			else
			  end=metadata_outlinks.get(len-1);
			raf.seek(start);
			offset1=start;
			flag=false;
			while(offset1<=end)
			{
				temp1=raf.readLine();
				temp2=temp1.substring(0,temp1.indexOf('#'));
				offset=Long.parseLong(temp1.substring(temp1.indexOf('#')+1));
				if(temp.compareTo(temp2)<0)
				{
					if(offset1==start)
						offset=-1;
					break;
				}
				offset2=offset;
				if(temp.equals(temp2))
				{
					flag=true;
					//writeLog("found in index");
					break;
				}
				offset1+=temp1.length()+2;
			}
			if(offset==-1)
			{	
				//writeLog("word:'"+temp+"' not found");
			    break;
			}
			else
			{
				raf1.seek(offset2);
				if(flag)
				{
					temp1=raf1.readLine();
					//writeLog("word found!!(in index)");
					//writeLog(temp1);
					break;
				}
				else
				{ 
					temp1=null;
					offset1=offset2;
					while(offset1<=offset)
					{
						temp1=raf1.readLine();
						offset1+=temp1.length()+2;
						if(temp1.substring(0, temp1.indexOf('#')).equals(temp))
						{   flag1=true;break;}
						if(temp1.substring(0, temp1.indexOf('#')).compareTo(temp)>0)
							break;
					}
					if(temp1==null)
					{	
						//writeLog("word:'"+temp+"' not found");
					    break;
					}
					else if(flag1)
					{
						//writeLog("word found!!");
						//writeLog(temp1);
						break;		
					}
					else
					{
						//writeLog("word:'"+temp+"' not found");
						flag1=false;
						break;
					}
				}
			}
		    }
			if(temp1!=null)
	        {
	        	String[] temp4=temp1.substring(temp1.indexOf('#')+1).split("#");
	        	int len2=temp4.length;
	        	for(String s:temp4)
	        	{
	        		long pid=Long.parseLong(s.substring(0,s.indexOf(':')));
	        		double curr_val,prev_val;
	        		curr_val=Double.parseDouble(s.substring(s.indexOf(':')+1));
	        		curr_val=curr_val*Math.log10(pageCount/len2);
	        		if(rank_outlinks.containsKey(new Long(pid)))
	        		{
	        	       prev_val=rank_outlinks.get(pid).doubleValue();
	        	       rank_outlinks.put(new Long(pid), new Double((curr_val+prev_val)*10));
	        		}
	        		else
	        			rank_outlinks.put(new Long(pid),new Double(curr_val));
	        	}
	        }
	        //compute();
	   }
		/*synchronized(this)
		{
			print(rank_outlinks);
		}*/
		//System.out.println(x+" words found!!");

    }
    
    public void print(TreeMap<Long,Double> tm)
    {
    	Set<Map.Entry<Long,Double>> set = tm.entrySet();
		Iterator<Map.Entry<Long,Double>> iterator = set.iterator();
		writeLog("{",false);
    	while(iterator.hasNext()) {
			Map.Entry<Long,Double> entry = (Map.Entry<Long,Double>)iterator.next();
			try{
			writeLog(entry.getKey()+":"+entry.getValue()+",",false);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
    	}
    	writeLog("}",false);
    }
    
    public void globalRank()
    {
    	TreeMap<Long,Double> tm=null;
    	TreeMap<Long,Double> temp_tm=null;
    	double weight=0.0001;
    	long key1,key2;
    	double value1,value2;
    	boolean flag=false;
    	for(int i=1;i<=5;i++)
    	{
    		switch(i)
    		{
    		   case 1:
    			   tm=rank_title;
    			   weight=1;
    			   break;
    		   case 2:
    			   tm=rank_category;
    			   weight=0.5;
    			   break;
    		   case 3:
    			   tm=rank_content;
    			   weight=0.1;
    			   break;
    		   case 4:
    			   tm=rank_infobox;
    			   weight=0.75;
    			   break;
    		   case 5:
    			   tm=rank_outlinks;
    			   weight=0.25;
    			   break;
    		}	
    	    if(i==1)
    	    {
    	    	rank=copy(tm);
        	   temp_tm=copy(rank);	
        	   /*synchronized(this)
   			   {writeLog("");
   	    	   writeLog("****globalrank initially***");
   			    writeLog("");
   			    writeLog("");
   				print(temp_tm);
   			   }*/
        	   results+=temp_tm.size();
        	   /*if(temp_tm==null)
        	   {
        		  System.out.println("temp_tm is null");
        	   }*/
    	    }
            else
            {
            	Set<Map.Entry<Long,Double>> set = tm.entrySet();
            	Iterator<Map.Entry<Long,Double>> iterator = set.iterator();
            	while(iterator.hasNext()) 
            	{
            		Map.Entry<Long,Double> entry = (Map.Entry<Long,Double>)iterator.next();
            		key1=entry.getKey().longValue();
            		value1=entry.getValue().doubleValue();
            		Set<Map.Entry<Long,Double>> set1 = rank.entrySet();
            		Iterator<Map.Entry<Long,Double>> iterator1 = set1.iterator();
            		while(iterator1.hasNext()) 
            		{
            			Map.Entry<Long,Double> entry1 = (Map.Entry<Long,Double>)iterator1.next();
            			key2=entry1.getKey().longValue();
            			value2=entry1.getValue().doubleValue();
				        if(key1==key2)
				        {
					       flag=true;
					       temp_tm.put(new Long(key2), new Double((weight*value1+value2)*100));
					       /*synchronized(this)
		        			{writeLog("");
		        	    	   writeLog("****updated temp_tm***");
		        			    writeLog("");
		        			    writeLog("");
		        				print(temp_tm);
		        			}*/
					       break;
				        }
				        if(key1<key2)
					      break;
	    	        }
	    	        if(!flag)
	    	        {
	    		        temp_tm.put(new Long(key1), new Double(value1));results++;
	    		        /*synchronized(this)
	        			{writeLog("");
	        	    	   writeLog("****inserting into temp_tm***");
	        			    writeLog("");
	        			    writeLog("");
	        				print(temp_tm);
	        			}*/
	    		        flag=false;
	    	        }
    	        }
    	        rank=copy(temp_tm);
    	        /*synchronized(this)
    			{writeLog("");
    	    	   writeLog("****globalrank now is***");
    			    writeLog("");
    			    writeLog("");
    				print(rank);
    			}*/
           }
    	}
    	try{
    	//writeLog("******************printing gloabal rank*********");
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	//print(rank);
    	/*synchronized(this)
		{writeLog("");
    	   writeLog("****globalrank fianlly***");
		    writeLog("");
		    writeLog("");
			print(rank);
		}*/
    }
    
    
    public TreeMap<Long,Double> copy(TreeMap<Long,Double> src)
    {
    	TreeMap<Long,Double> dest=new TreeMap<Long,Double>();
    	Set<Map.Entry<Long,Double>> set2 = src.entrySet();
		Iterator<Map.Entry<Long,Double>> iterator2 = set2.iterator();
    	while(iterator2.hasNext()) {
			Map.Entry<Long,Double> entry2 = (Map.Entry<Long,Double>)iterator2.next();
			dest.put(new Long(entry2.getKey().longValue()), new Double(entry2.getValue().doubleValue()));
		
	   }
       return dest;
    }
    
    public void gettop10pids()
    {
    	TreeMap<Long,Double> tm;
    	int i=0;
    	boolean flag=false;
    	tm=new MapValueSort().sortOnValue(rank);
    	/*System.out.println("size of rank:"+rank.size());
    	System.out.println(rank);
    	System.out.println("size of tm:"+tm.size());
    	System.out.println(tm);
    	System.out.println("size:(before)"+top10pageids.size());*/
    	//writeLog("***************printing sorted rank treemap*****");
    	//print(tm);
    	Set<Map.Entry<Long,Double>> set = tm.entrySet();
		Iterator<Map.Entry<Long,Double>> iterator = set.iterator();
    	while(iterator.hasNext()) {
			Map.Entry<Long,Double> entry = (Map.Entry<Long,Double>)iterator.next();
			Set<Map.Entry<Long,Double>> set1 = rank.entrySet();
			Iterator<Map.Entry<Long,Double>> iterator1 = set1.iterator();
	    	while(iterator1.hasNext()) {
				Map.Entry<Long,Double> entry1 = (Map.Entry<Long,Double>)iterator1.next();
				//System.out.println("!!!");
				//System.out.println("key:"+entry1.getKey());
				//System.out.println("key:"+entry1.getKey());
				if(entry.getValue().doubleValue()==entry1.getValue().doubleValue())
				{
					top10pageids.add(entry1.getKey());
					i++;
					if(i==20)
					{
						flag=true;
						break;
					}
				}
	    	}
	    	if(flag)
	    	{
	    		break;
	    	}
    	}
    	//System.out.println("flag="+flag);
    	//System.out.println("size:"+top10pageids.size());
    	//System.out.println("top 10 pids are:");
    	/*for(int j=0;j<top10pageids.size();j++)
    		System.out.print(top10pageids.get(j)+",");
    	System.out.println(top10pageids);*/
    }
    
    public void getPageTitles() throws IOException
    {
    	String temp1=null;
    	for(Long l:top10pageids)
    	{
    		RandomAccessFile raf,raf1 ;
    		int len=0;
    		long offset=0,start=0,end=0,offset1=0,offset2=0;
    		boolean flag=false,flag1=false;
    		int index;
    		String temp,temp2;
    		raf= new RandomAccessFile(Search1.indexPath+"index_page-titles.txt", "r");
    		raf1=new RandomAccessFile(Search1.path+"page-titles.txt", "r");
    		len=metadata_page_titles.size();
    		//System.out.println("metadata page titles:");
    		//System.out.println(metadata_page_titles);
    		//len1=top10pageids.size();
    		temp=l+"";
    		index=temp.charAt(0)-49;
    		while(true && index>=0){
    			if(index<len)
    		     start=metadata_page_titles.get(index);
    			else
    				start=metadata_page_titles.get(len-2);	
    		if(index+1<len)
    		  end=metadata_page_titles.get(index+1);
    		else
    		  end=metadata_page_titles.get(len-1);
    		//System.out.println("start="+start+"\tend="+end);
    		raf.seek(start);
    		offset1=start;
    		flag=false;
    		while(offset1<=end)
    		{
    			temp1=raf.readLine();
    			//System.out.println("temp1="+temp1);
    			temp2=temp1.substring(0,temp1.indexOf('#'));
    			offset=Long.parseLong(temp1.substring(temp1.indexOf('#')+1));
    			if(temp.compareTo(temp2)<0)
    			{
    				if(offset1==start)
    					offset=-1;
    				    break;
    			}
    			offset2=offset;
    			if(temp.equals(temp2))
    			{
    				flag=true;
    				break;
    			}
    			offset1+=temp1.length()+2;
    		}
    		if(offset==-1)
    		{	
    			//System.out.println("word:'"+temp+"' not found");
    			break;
    		}
    		else
    		{
    			raf1.seek(offset2);
    			if(flag)
    			{
    				temp1=raf1.readLine();
    				//System.out.println("word found!!(in index)");
    				System.out.println("\t\t\t"+temp1.substring(temp1.indexOf('#')+1));
    				break;
    			}
    			else
    			{ 
    				temp1=null;
    				offset1=offset2;
    				while(offset1<=offset)
    				{
    					temp1=raf1.readLine();
    					/*if(offset1==offset2)
    						System.out.println("temp1="+temp1);
    					if(temp1==null)
    						System.out.println("offset="+offset);*/
    					offset1+=temp1.length()+2;
    					//System.out.println("temp1="+temp1);
    					if(temp1.indexOf('#')==-1)
    						System.out.println("temp1="+temp1);
    					if(temp1.substring(0, temp1.indexOf('#')).equals(temp))
    					{   
    						flag1=true;
    						break;
    					}
    					if(temp1.substring(0, temp1.indexOf('#')).compareTo(temp)>0)
    						break;
    				}
    				if(temp1==null)
    				{	
    					//System.out.println("word:'"+temp+"' not found");
    					break;
    				}
    				else if(flag1)
    				{
    					//System.out.println("word found!!");
    					System.out.println("\t\t\t"+temp1.substring(temp1.indexOf('#')+1));
    					break;		
    				}
    				else
    				{
    					//System.out.println("word:'"+temp+"' not found");
    					flag1=false;
    					break;
    				}
    			}
    		}
    	}
    	//System.out.println(temp1);
      }
    	t2=System.currentTimeMillis();
    	System.out.println("\t\t\t\t\t\t("+results+" found in "+ (t2-t1)/1000.0 +" secs)");
   }
    
   public void writeLog(String s)
   {
	   synchronized(this)
	   {
		   try{
	   bw.write(s);
	   bw.write(System.getProperty("line.separator"));
		   }
		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
	   }
   }
   public void writeLog(String s,boolean flag) 
   {
	   try{
		   synchronized(this)
		   {
	           bw.write(s);
		   }
	   }
	   catch(Exception e)
	   {
		   e.printStackTrace();
	   }
	   //bw.write(System.getProperty("line.separator"));
   }
}


//Create multiple threads.
class NewThreadv1 implements Runnable {
  Thread t;
  String name;
  Search1 s;  
  NewThreadv1(String threadname,Search1 obj) throws IOException {
    name = threadname;
    t = new Thread(this, name);
    s=obj;
    t.start(); // Start the thread
  }

  // This is the entry point for thread.
  public void run() {
    try {
     
    	int index;
    	index=Integer.parseInt(t.getName());
    	switch(index)
    	{
    	    case 1:
    	    	s.findTitle();
    	    	break;
    	    case 2:
    	    	s.findCategory();
    	    	break;
    	    case 3:
    	    	s.findContent();
    	    	break;
    	    case 4:
    	    	s.findInfobox();
    	    	break;
    	    case 5:
    	    	s.findOutlinks();
    	    	break;
    	}
    } catch (Exception e) {
      System.out.println(name + "Interrupted");
    }
  }
}
