package sample;

public class Test3 {

	
	public static void main(String[] args) {
		String path="c:/ire/index/index.zip";
		String temp=path.substring(0, path.lastIndexOf('/'));
		temp=temp.substring(0,temp.lastIndexOf('/')+1);
		new UnZip(path,temp);
	}

}
