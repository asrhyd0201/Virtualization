package sample;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

public class MapValueSort {

	/** inner class to do soring of the map **/
	private static class ValueComparer implements Comparator<Object> {
		private Map<Long, Double>  _data = null;
		public ValueComparer (Map<Long, Double> data){
			super();
			_data = data;
		}

         public int compare(Object o1, Object o2) {
        	 Double e1 = (Double)_data.get(o1);
             Double e2 = (Double)_data.get(o2);
             return -1*e1.compareTo(e2);
         }
	}

	public static void main(String[] args){

		Map<Long,Double> unsortedData = new HashMap<Long,Double>();
		unsortedData.put(new Long(12), new Double(23.44));
		unsortedData.put(new Long(34), new Double(23.44));
		unsortedData.put(new Long(10), new Double(43));
		unsortedData.put(new Long(11), new Double(22));

		SortedMap<Long,Double> sortedData = new TreeMap<Long, Double>(new MapValueSort.ValueComparer(unsortedData));

		printMap(unsortedData);

		sortedData.putAll(unsortedData);
		System.out.println();
		printMap(sortedData);
	}

	public TreeMap<Long,Double> sortOnValue(TreeMap<Long,Double> tm)
	{
		TreeMap<Long,Double> sortedData = new TreeMap<Long, Double>(new MapValueSort.ValueComparer(tm));
		sortedData.putAll(tm);
		return sortedData;
	}
	public static void printMap(Map<Long,Double> data) {
		for (Iterator<Long> iter = data.keySet().iterator(); iter.hasNext();) {
			Long key = iter.next();
			System.out.println("Value/key:"+data.get(key)+"/"+key);
		}
	}

}