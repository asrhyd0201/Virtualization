package sample;

import java.util.ArrayList;

public class TestArrayList {

	public static void main(String[] args) {
		ArrayList<Integer> l=new ArrayList<Integer>();
		int size=6,x,y,n,z=0;
		for(int i=0;i<size;i++)
			l.add(i,i+1);
		for(int i=0;i<l.size();i++)
			   System.out.print(l.get(i)+",");
		   System.out.println("");
		n=size;
		while(l.size()!=1)
		{  
		   for(int i=0;i+1<l.size();i++)
		   {
			   x=l.remove(i);
			   y=l.remove(i);
			   z=n+(i+1);
			   l.add(i, z);
			   System.out.println("merge("+x+","+y+")"+" into "+l.get(i));
		   }
		   n=z;
		   for(int i=0;i<l.size();i++)
			   System.out.print(l.get(i)+",");
		   System.out.println("");
		}
	}
}
