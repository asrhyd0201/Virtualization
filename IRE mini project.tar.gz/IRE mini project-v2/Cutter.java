package sample;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class Cutter extends DefaultHandler
{
	BufferedOutputStream bw;
	boolean page,file,title,id,text,flag;
	int count,files;
	Cutter(String inputfile) throws IOException, ParserConfigurationException, SAXException
	{
		bw=new BufferedOutputStream(new FileOutputStream("C:/Users/Manikanta/Desktop/test/wiki1.xml"));
		count=0;files=1;
		flag=false;
		SAXParserFactory factory = SAXParserFactory.newInstance();
        SAXParser saxParser = factory.newSAXParser();
        saxParser.parse(new File(inputfile), this);
	}
	public static void main(String args[]) throws IOException, ParserConfigurationException, SAXException
	{
		new Cutter("C:/Users/Manikanta/Desktop/test/wiki100mb.xml");	
	}
	
	public void startElement(String uri,String localName,String qname,Attributes attr) throws SAXException
	{
		if(qname.equalsIgnoreCase("file"))
		{
			file=true;
			try {
				bw.write("<file>".getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(qname.equalsIgnoreCase("page"))
		{
			page=true;
			try {
				bw.write("<page>".getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
			flag=true;
		}
		if(qname.equalsIgnoreCase("title"))
		{
			title=true;
			try {
				bw.write("<title>".getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(qname.equalsIgnoreCase("text"))
		{
			text=true;
			try {
				bw.write("<text>".getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	public void endElement(String uri,String localName,String qname) throws SAXException
	{
		if(qname.equalsIgnoreCase("file"))
		{
			file=false;
			if(!flag){
			try {
				bw.write("</file>".getBytes());
				bw.flush();
				bw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}}
		}
		if(qname.equalsIgnoreCase("page"))
		{
			page=false;
			count++;
			try {
				bw.write("</page>".getBytes());
				if(count%500==0){
					bw.write("</file>".getBytes());
					files++;
					bw.flush();
					bw.close();
					bw=new BufferedOutputStream(new FileOutputStream("C:/Users/Manikanta/Desktop/test/wiki"+files+".xml"));
					bw.write("<file>".getBytes());
					flag=true;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(qname.equalsIgnoreCase("title"))
		{
			title=false;
			id=true;
			try {
				bw.write("</title>".getBytes());
				bw.write("<id>".getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(qname.equalsIgnoreCase("id") && id)
		{
			id=false;
			try {
				bw.write("</id>".getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(qname.equalsIgnoreCase("text"))
		{
			text=false;
			try {
				bw.write("</text>".getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	public void characters(char[] chars, int start, int length) throws SAXException 
	{
		if(title|id|text)
			write(new String(chars,start,length));
	}
	
	public void write(String s)
	{
		try{
		bw.write(s.getBytes());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

