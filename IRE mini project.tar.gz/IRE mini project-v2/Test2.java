package sample;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class Test2 extends DefaultHandler{

	private boolean text,title,id;
    //private BufferedWriter outputStream,cat,outlink,outlink_title,inf,tit;
    private StringBuffer sb,value;
    public TreeMap <String,StringBuffer>data;
    public TreeMap <String,StringBuffer>category;
    public TreeMap <String,StringBuffer>Title;
    public TreeMap <String,StringBuffer>infobox;
    public TreeMap <String,StringBuffer>out;
    public TreeMap <String,StringBuffer>redirect;
    public TreeMap <String,StringBuffer>Title_Page;
    public String pageTitle,pageId;
    private String tempdata;
    private String temp,temp1,temp2;
	private StopWordRemoval sw;
	private Porter pstem;
	private Pattern p1,p2,p3,p4,p5,p6;
	public long pageCount;
	private long fileCount;
	private ArrayList<Integer> l;
	private long indexOffset;
	private String path;
	private boolean redirect_flag;
    private String redirect_title; 	
	//BufferedWriter bw;
    /*outlinks has title of other page->visible part of page,seperated by '-:'*/
	Test2(String inputfile,String p)
	{
		try 
		{
			//path="C:/Users/Manikanta/Desktop/test/IRE/";
			path=p;
			pageCount=fileCount=0;
			indexOffset=0;
			l=new ArrayList<Integer>();
			p1 = Pattern.compile("\\n+|[^\\p{ASCII}]+|"+System.getProperty("line.separator")+"+");
			redirect_flag=false;
			p6 = Pattern.compile("#REDIRECT\\s+\\[\\[(.+?)\\]\\]");
			p2 = Pattern.compile("(\\[\\[[cC]ategory:(.+?)\\]\\])|(\\{\\{[iI]nfo[bB]ox\\s+(.+?)\\|.*?\\}\\})");
			//p3 = Pattern.compile("\\{\\{([iI]nfo)[bB]ox.+?\\}\\}");
			p3 = Pattern.compile("\\[\\[.+?\\]\\]");
			p4 = Pattern.compile("\\p{Alpha}+");
			p5 = Pattern.compile("(http://.+?(\\s|>|\\]|\\}))|(\\{\\{[cC](ite|itation).+?\\}\\})|(<ref.*?>.+?</ref>)|(<.+?>)|(<.+?>.*?<.+?>)");
			//outputStream=null;
			text=title=id=false;
			data=new TreeMap<String,StringBuffer>();
			redirect=new TreeMap<String,StringBuffer>();
			category=new TreeMap<String,StringBuffer>();
			Title=new TreeMap<String,StringBuffer>();
			infobox=new TreeMap<String,StringBuffer>();
			out=new TreeMap<String,StringBuffer>();
			Title_Page = new TreeMap<String,StringBuffer>();
			//bw=new BufferedWriter(new FileWriter("log.txt"));
			value=new StringBuffer(1000);
			sb = new StringBuffer(16000);
			sw=new StopWordRemoval();
			pstem=new Porter();
			SAXParserFactory factory = SAXParserFactory.newInstance();
	         SAXParser saxParser = factory.newSAXParser();
	         saxParser.parse(new File(inputfile), this);
	    } 
		catch (Exception e) 
		{
			e.printStackTrace();
	    }
	}
	
	public static void main(String[] args) throws Exception
	{
	   String infile=null;
	   infile=new String("C:/ire2/xaaaa");
	   new Test2(infile,"C:/index_files/");
	}

	public void startElement(String uri,String localName,String qname,Attributes attr) throws SAXException
	{ 
		if(qname.equalsIgnoreCase("text"))
		{
			text=true;
		}
		if(qname.equalsIgnoreCase("title"))
		{
			title=true;
		}
	}
	
	public void endElement(String uri,String localName,String qname) throws SAXException
	{ 
		if(qname.equalsIgnoreCase("text"))
		{
			tempdata=new String(sb);
			tempdata=replacePatternBy(1);
			tempdata=replacePatternBy(5);
			tempdata=replacePatternBy(4);
			tempdata=replacePatternBy(2);
			tempdata=replacePatternBy(3);
			//tokenize();
			write(tempdata,1);
			pageCount++;
			text=false;
			sb.delete(0, sb.length());
			if(pageCount%2000==0)
			{
				try {
					writeToFile(data,1);
					writeToFile(category,2);
					writeToFile(infobox,3);
					writeToFile(redirect,4);
					writeToFile(out,5);
					writeToFile(Title,6);
					writeToFile(Title_Page,7);
					data.clear();
					category.clear();
					infobox.clear();
					redirect.clear();
					out.clear();
					Title.clear();
					Title_Page.clear();
					fileCount++;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		if(qname.equalsIgnoreCase("title"))
		{
			title=false;
			id=true;
		}
		if(qname.equalsIgnoreCase("id"))
		{
			id=false;
			writeTitle(pageTitle);
		}
		if(qname.equalsIgnoreCase("file"))
		{
			try {
				writeToFile(data,1);
				writeToFile(category,2);
				writeToFile(infobox,3);
				writeToFile(redirect,4);
				writeToFile(out,5);
				writeToFile(Title,6);
				writeToFile(Title_Page,7);
				if(!Title.isEmpty())
					fileCount++;
				data.clear();
				category.clear();
				infobox.clear();
				redirect.clear();
				out.clear();
				Title.clear();
				Title_Page.clear();
				merge();
				/*String[] files={path+"data.txt",path+"infobox.txt",path+"category.txt",path+"outlinks.txt",path+"titles.txt",path+"page-titles.txt"};
				new Zip(files,"index.zip");
				File f1=new File(files[0]);
				f1.delete();
				f1=new File(files[1]);
				f1.delete();
				f1=new File(files[2]);
				f1.delete();
				f1=new File(files[3]);
				f1.delete();
				f1=new File(files[4]);
				f1.delete();
				f1=new File(files[5]);
				f1.delete();*/
				
				/*String[] files1={path+"index_data.txt",path+"metadata_data.txt",path+"index_category.txt",path+"metadata_category.txt",path+"index_infobox.txt",path+"metadata_infobox.txt",path+"index_outlinks.txt",path+"metadata_outlinks.txt",path+"index_titles.txt",path+"metadata_titles.txt",path+"index_page-titles.txt",path+"metadata_page-titles.txt"};
				new Zip(files1,"indexOnIndex.zip");
				f1=new File(files1[0]);
				f1.delete();
				f1=new File(files1[1]);
				f1.delete();
				f1=new File(files1[2]);
				f1.delete();
				f1=new File(files1[3]);
				f1.delete();
				f1=new File(files1[4]);
				f1.delete();
				f1=new File(files1[5]);
				f1.delete();
				f1=new File(files1[6]);
				f1.delete();
				f1=new File(files1[7]);
				f1.delete();
				f1=new File(files1[8]);
				f1.delete();
				f1=new File(files1[9]);
				f1.delete();
				f1=new File(files1[10]);
				f1.delete();
				f1=new File(files1[11]);
				f1.delete();*/
				BufferedWriter bw=new BufferedWriter(new FileWriter(path+"metadata.txt"));
				bw.write(pageCount+"");
				bw.write(System.getProperty("line.separator"));
				bw.flush();
				bw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void characters(char[] chars, int start, int length) throws SAXException 
	{
		if(text)
		{
			sb.append(new String(chars,start,length));
		}
		if(title)
		{
			pageTitle=new String(chars,start,length).trim();
		}
		if(id)
		{
			pageId=new String(chars,start,length).trim();
		}
	}

	private String replacePatternBy(int i)
	{
		Matcher m=null;
		switch(i)
		{
		   case 1:
                 m = p1.matcher(tempdata);
                 break;
		   case 2:
	             m = p2.matcher(tempdata);
	             break;
		   case 3:
	             m = p3.matcher(tempdata);
	             break;
		   case 4:
			     m=p5.matcher(tempdata);
			     break;
		   case 5:
			     m=p6.matcher(tempdata);
			     break;
		}
        
        	switch(i)
        	{
        	   case 2:
        		 while(m.find()){
               	    temp=m.group(1);
               	    if(temp!=null){
               		temp=m.group(2).trim().toLowerCase();
               		write(temp,2);
               	    }
        			 temp=m.group(3);
        			 if(temp!=null){
        	         temp=m.group(4).trim().toLowerCase();
        	         write(temp,3);
        			 }
              	 }
              	 break;
              
        	   case 3:
        		   while(m.find()){
        		   temp=m.group();
        		   if(temp!=null){
        		   if(temp.indexOf(':')==-1)
        		   {
        			   if(temp.indexOf('|')!=-1)
               		   {
        				   temp1=temp.substring(temp.indexOf('|')+1,temp.length()-2).trim();
        				   temp1=temp1.toLowerCase();
               			   //temp2 is title of another page
               			   temp2=temp.substring(2,temp.indexOf('|')).trim();
               			   temp2=temp2.toLowerCase();
               			   write(temp1,5);
               			   write(temp2,5);
               		   }
        			   else
        			   {
        				   temp1=temp.substring(2,temp.length()-2).trim();
               			   temp1=temp1.toLowerCase();
               			   write(temp1,5);
        			   }
        		   }}}
        		   break;
        	   case 5:
        		  while(m.find())
        		  {
        			  temp=m.group();
        			  if(temp!=null)
        			  {
        				  temp=m.group(1).trim().toLowerCase();
        				  redirect_title=temp;
        				  redirect_flag=true;
        			  }
        		  }
        		  break;
            }
        m.reset();
        temp=m.replaceAll(" ");
        return temp;
    }
        
	private void write(String s,int index) 
	{
		TreeMap <String,StringBuffer> t=null;
		int i=0;
		//String str[];
		switch(index)
		{
		    case 1:
		    	t=data;
		    	break;
		    case 2:
		    	t=category;
		    	break;
		    case 3:
		    	t=infobox;
		    	break;
		    case 5:
		    	t=out;
		    	break;
		}
		//str=s.split(" ");
		/*for(j=0;j<str.length;j++)
		{*/
			Matcher m = p4.matcher(s);
	        while(m.find())
	        {
	        	temp=m.group().trim();
	        	temp=temp.toLowerCase();
	        	temp=pstem.stripAffixes(temp);
	        	if(temp.length()>2){
	        	if(!sw.isStopWord(temp))
	        	{
	        		if(t.containsKey(temp))
                    {	
	        			value=t.get(temp);
	        			i=value.lastIndexOf("#"+pageId+":");
	        			if(i!=-1)
	        			{
	        				setAndIncrementCount(temp,t);
	        			}
	        			else
	        			{
	        				t.put(temp,value.append("#"+pageId+":1"));
	        			}
	        		}
	        		else
	        		{
	        			t.put(temp,new StringBuffer("#"+pageId+":1"));
	        		}
	        	}
	        }
	    }
	  //}
	}

	private void writeTitle(String title)
	{
		Matcher m = p4.matcher(title);
		while(m.find())
		{
		   temp=m.group().trim().toLowerCase();
		   temp=pstem.stripAffixes(temp);
       	if(temp.length()>2){
       	if(!sw.isStopWord(temp))
       	{
		   Title.put(temp, new StringBuffer("#"+pageId));
       	}
       	}
		}
		Title_Page.put(pageId,new StringBuffer("#"+title));
		if(redirect_flag)
		{
		   redirect.put(pageId,new StringBuffer("#"+redirect_title));
		   redirect_flag=false;
		}
	}
	private void writeToFile(TreeMap<String,StringBuffer> t,int index) throws IOException
	{
		BufferedWriter bw=null;
		//if(!t.isEmpty()){
		switch(index)
		{
		    case 1:
		    	bw=new BufferedWriter(new FileWriter(path+"data"+(fileCount+1)));
		    	break;
		    case 2:
		    	bw=new BufferedWriter(new FileWriter(path+"category"+(fileCount+1)));
		    	break;
		    case 3:
		    	bw=new BufferedWriter(new FileWriter(path+"infobox"+(fileCount+1)));
		    	break;
		    case 4:
		    	bw=new BufferedWriter(new FileWriter(path+"redirect"+(fileCount+1)));
		    	break;
		    case 5:
		    	bw=new BufferedWriter(new FileWriter(path+"outlinks"+(fileCount+1)));
		    	break;
		    case 6:
		    	bw=new BufferedWriter(new FileWriter(path+"titles"+(fileCount+1)));
		    	break;
		    case 7:
		    	bw=new BufferedWriter(new FileWriter(path+"titles-page"+(fileCount+1)));
		    	break;
		}
		Set<Map.Entry<String,StringBuffer>> set = t.entrySet();
		Iterator<Map.Entry<String,StringBuffer>> iterator = set.iterator();

		while(iterator.hasNext()) {
			Map.Entry<String,StringBuffer> entry = (Map.Entry<String,StringBuffer>)iterator.next();
		    bw.write(entry.getKey() + entry.getValue());	
		    bw.write(System.getProperty("line.separator"));
		}
		bw.flush();
		bw.close();	
		//}	
	}
	public void setAndIncrementCount(String key,TreeMap <String,StringBuffer> t)
	{
		StringBuffer temp=null;
		int i=0;
		int len=0;
	    temp=t.get(key);
	    i=temp.indexOf("#"+pageId+":");
	    i=temp.indexOf(":", i+1);
	    len=Integer.parseInt(temp.substring(i+1))+1;
	    temp.delete(i+1, temp.length());
	    temp.append(len);
		data.put(key, temp);
	}
	
	public void merge()
	{
		int x,y;
		long z=0,n;
		for(int a=1;a<=7;a++){
		for(int i=0;i<fileCount;i++)
			l.add(i,i+1);
		n=fileCount;
		while(l.size()!=1)
		{  
		   for(int i=0;i+1<l.size();i++)
		   {
			   x=l.remove(i);
			   y=l.remove(i);
			   z=n+(i+1);
			   l.add(i, (int)z);
			   //System.out.println("merge("+x+","+y+")"+" into "+l.get(i));
			   mergeFiles(x,y,l.get(i).intValue(),a);
		   }
		   n=z;
		}
		l.clear();
		indexOffset=0;
		}
	}
	
	public void mergeFiles(int x,int y,int z,int index) 
	{
		BufferedReader in1=null,in2=null;
		BufferedWriter out=null;
		String in1line=null,in2line=null;
		BufferedWriter primaryIndex=null;
		BufferedWriter metaIndex=null;
		File f1=null,f2=null;
		long offset=0,linecount=1;
		boolean flag1=true,flag2=true;
		char current,prev='!';
		String temp;
		try{
		switch(index)
		{
		   case 1:
			 if(l.size()==1)
			 {
				 out=new BufferedWriter(new FileWriter(path+"data.txt"));
				 primaryIndex=new BufferedWriter(new FileWriter(path+"index_data.txt"));
				 metaIndex=new BufferedWriter(new FileWriter(path+"metadata_data.txt"));
			 }
			 else
				 out=new BufferedWriter(new FileWriter(path+"data"+z));
			 in1=new BufferedReader(new FileReader(path+"data"+x));
			 in2=new BufferedReader(new FileReader(path+"data"+y));
			 f1=new File(path+"data"+x);
			 f2=new File(path+"data"+y);
			 break;
		   case 2:
				 if(l.size()==1)
				 {
					 out=new BufferedWriter(new FileWriter(path+"category.txt"));
					 primaryIndex=new BufferedWriter(new FileWriter(path+"index_category.txt"));
					 metaIndex=new BufferedWriter(new FileWriter(path+"metadata_category.txt"));
				 }
				 else
					 out=new BufferedWriter(new FileWriter(path+"category"+z));
				 in1=new BufferedReader(new FileReader(path+"category"+x));
				 in2=new BufferedReader(new FileReader(path+"category"+y));
				 f1=new File(path+"category"+x);
				 f2=new File(path+"category"+y);
				 break;
		   case 3:
				 if(l.size()==1)
				 {
					 out=new BufferedWriter(new FileWriter(path+"infobox.txt"));
					 primaryIndex=new BufferedWriter(new FileWriter(path+"index_infobox.txt"));
					 metaIndex=new BufferedWriter(new FileWriter(path+"metadata_infobox.txt"));
				 }
				 else
					 out=new BufferedWriter(new FileWriter(path+"infobox"+z));
				 in1=new BufferedReader(new FileReader(path+"infobox"+x));
				 in2=new BufferedReader(new FileReader(path+"infobox"+y));
				 f1=new File(path+"infobox"+x);
				 f2=new File(path+"infobox"+y);
				 break;
		   case 4:
				 if(l.size()==1)
				 {
					 out=new BufferedWriter(new FileWriter(path+"outlinks.txt"));
					 primaryIndex=new BufferedWriter(new FileWriter(path+"index_outlinks.txt"));
					 metaIndex=new BufferedWriter(new FileWriter(path+"metadata_outlinks.txt"));
				 }
				 else
					 out=new BufferedWriter(new FileWriter(path+"outlinks"+z));
				 in1=new BufferedReader(new FileReader(path+"outlinks"+x));
				 in2=new BufferedReader(new FileReader(path+"outlinks"+y));
				 f1=new File(path+"outlinks"+x);
				 f2=new File(path+"outlinks"+y);
				 break;
		   case 5:
				 if(l.size()==1)
				 {
					 out=new BufferedWriter(new FileWriter(path+"titles.txt"));
					 primaryIndex=new BufferedWriter(new FileWriter(path+"index_titles.txt"));
					 metaIndex=new BufferedWriter(new FileWriter(path+"metadata_titles.txt"));
				 }
				 else
					 out=new BufferedWriter(new FileWriter(path+"titles"+z));
				 in1=new BufferedReader(new FileReader(path+"titles"+x));
				 in2=new BufferedReader(new FileReader(path+"titles"+y));
				 f1=new File(path+"titles"+x);
				 f2=new File(path+"titles"+y);
				 break;
		   case 6:
				 if(l.size()==1)
				 {
					 out=new BufferedWriter(new FileWriter(path+"page-titles.txt"));
					 primaryIndex=new BufferedWriter(new FileWriter(path+"index_page-titles.txt"));
					 metaIndex=new BufferedWriter(new FileWriter(path+"metadata_page-titles.txt"));
				 }
				 else
					 out=new BufferedWriter(new FileWriter(path+"titles-page"+z));
				 in1=new BufferedReader(new FileReader(path+"titles-page"+x));
				 in2=new BufferedReader(new FileReader(path+"titles-page"+y));
				 f1=new File(path+"titles-page"+x);
				 f2=new File(path+"titles-page"+y);
				 break;
		   case 7:
				 if(l.size()==1)
				 {
					 out=new BufferedWriter(new FileWriter(path+"redirect.txt"));
					 primaryIndex=new BufferedWriter(new FileWriter(path+"index_redirect.txt"));
					 metaIndex=new BufferedWriter(new FileWriter(path+"metadata_redirect.txt"));
				 }
				 else
					 out=new BufferedWriter(new FileWriter(path+"redirect"+z));
				 in1=new BufferedReader(new FileReader(path+"redirect"+x));
				 in2=new BufferedReader(new FileReader(path+"redirect"+y));
				 f1=new File(path+"redirect"+x);
				 f2=new File(path+"redirect"+y);
				 break;
		}
		while(true)
		{
			if(flag1)
			{in1line=in1.readLine();
			if(in1line==null)
				break;}
			if(flag2){
			in2line=in2.readLine();
			if(in2line==null)
				break;}
			temp1=in1line.split("#")[0];
			temp2=in2line.split("#")[0];
			if(temp2.compareTo(temp1)>0)
			{
				out.write(in1line);
				out.write(System.getProperty("line.separator"));
				if(l.size()==1)
				{
					current=in1line.charAt(0);
					if(linecount%100==0 || prev!=current){
		            if(prev!=current)			
		            {    
					      createIndex(offset,in1line,true,primaryIndex,metaIndex);
		            }
		            else
		            {
		                  createIndex(offset,in1line,false,primaryIndex,metaIndex);	
		            }
					}
					prev=current;
		            offset+=in1line.length()+2;
		            linecount++;
				}
				flag1=true;
				flag2=false;
			}
			else if(temp2.compareTo(temp1)<0)
			{
				out.write(in2line);
				out.write(System.getProperty("line.separator"));
				if(l.size()==1)
				{
					current=in2line.charAt(0);
					if(linecount%100==0 || prev!=current){
		            if(prev!=current)			
		            {  
					     createIndex(offset,in2line,true,primaryIndex,metaIndex);
		            }
		            else
		            {
		                  createIndex(offset,in2line,false,primaryIndex,metaIndex);	
		            }}
		            offset+=in2line.length()+2;
		            prev=current;
		            linecount++;

				}
				flag1=false;
				flag2=true;
			}
			else
			{
				temp=in1line+in2line.substring(in2line.indexOf('#'));
				out.write(temp);
				out.write(System.getProperty("line.separator"));
				if(l.size()==1)
				{
					current=in1line.charAt(0);
					if(linecount%100==0 || prev!=current){
		            if(prev!=current)			
		            {    
					      createIndex(offset,in1line,true,primaryIndex,metaIndex);
		            }
		            else
		            {
		                  createIndex(offset,in1line,false,primaryIndex,metaIndex);
		            }}
		            offset+=temp.length()+2;
		            prev=current;
		            linecount++;
				}
				flag1=flag2=true;
			}
		}
		while((in1line=in1.readLine())!=null)
		{
			out.write(in1line);
			out.write(System.getProperty("line.separator"));
			if(l.size()==1)
			{
				current=in1line.charAt(0);
				if(linecount%100==0 || prev!=current){
	            if(prev!=current)			
	            {    
				      createIndex(offset,in1line,true,primaryIndex,metaIndex);
	            }
	            else
	            {
	            	  createIndex(offset,in1line,false,primaryIndex,metaIndex);
	            }}
	            offset+=in1line.length()+2;
	            prev=current;
	            linecount++;
			}
		}
		while((in2line=in2.readLine())!=null)
		{
			out.write(in2line);
			out.write(System.getProperty("line.separator"));
			if(l.size()==1)
			{
				current=in2line.charAt(0);
				if(linecount%100==0 || prev!=current){
	            if(prev!=current)			
	            {    
				      createIndex(offset,in2line,true,primaryIndex,metaIndex);
	            }
	            else
	            {
	                  createIndex(offset,in2line,false,primaryIndex,metaIndex);
	            }}
	            offset+=in2line.length()+2;
	            prev=current;
	            linecount++;
			}
		}
		//log("merged ("+x+","+y+") into"+z);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try{
			in1.close();
			in2.close();
			out.flush();
			out.close();
			if(f1.delete());
				//log("file-"+x+"deleted("+index+")");
			if(f2.delete());
				//log("file-"+y+"deleted("+index+")");
			if(l.size()==1)
			{
				   primaryIndex.flush();
				   primaryIndex.close();
				   metaIndex.flush();
				   metaIndex.close();
			}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	
	public void createIndex(long offset,String s,boolean metadata,BufferedWriter primaryIndex,BufferedWriter metaIndex)
	{
		String l;
			try{
			
		   	if(metadata)
		   	{
		   	   metaIndex.write(indexOffset+"");
		   	   metaIndex.write(System.getProperty("line.separator"));
		   	}
		   	s=s.substring(0, s.indexOf('#'));
		   	l=s+"#"+offset;
		   	primaryIndex.write(l);
		   	primaryIndex.write(System.getProperty("line.separator"));
		   	indexOffset+=l.length()+2;
		   	}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}

	
}



