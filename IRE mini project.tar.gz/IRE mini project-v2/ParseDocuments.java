package sample;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ParseDocuments 
{
	String indir,outdir;
	NewThread1[] t;
	String[] infiles;
	File inp;
	private ArrayList<Integer> l;
	private long indexOffset;
	private long pageCount;
	ParseDocuments(String in,String out) throws IOException, InterruptedException
	{
		long t1=System.currentTimeMillis()/1000;
		pageCount=indexOffset=0;
		indir=in+"/";
		outdir=out+"/";
		inp=new File(indir);
	   	infiles=inp.list();
	   	l=new ArrayList<Integer>();
	   	t=new NewThread1[infiles.length];
	   	for(int i=1;i<=infiles.length;i++)
	   	{
	   		t[i-1]=new NewThread1(i,this,infiles[i-1]);
	   	}
	   	for(int i=1;i<=infiles.length;i++)
	   	{
	   		t[i-1].t.join();
	   	}
	   	long t2=System.currentTimeMillis()/1000;
	   	System.out.println("time for splitting:"+(t2-t1));
	   	t1=System.currentTimeMillis()/1000;
	   	merge();
	   	writenoOfDocuments();
	   	t2=System.currentTimeMillis()/1000;
	   	System.out.println("time for merging:"+(t2-t1));
	   	t1=System.currentTimeMillis()/1000;
	   	new Zip(outdir);
	   	t2=System.currentTimeMillis()/1000;
	   	System.out.println("time for zipping:"+(t2-t1));
	}
	public static void main(String[] args) throws IOException, InterruptedException 
	{
		long startTime = System.currentTimeMillis()/1000;
		String indir,outdir;
	   	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	   	System.out.println("Enter input directory:");
	   	indir=br.readLine();
	   	System.out.println("Enter output directory:");
	   	outdir=br.readLine();
	   	ParseDocuments obj=new ParseDocuments(indir,outdir);
	   	long endTime = System.currentTimeMillis()/1000;
	   	System.out.println("total time:"+(endTime-startTime));

	}
	
	public void merge()
	{
		int x,y;
		long z=0,n;
		for(int i=0;i<infiles.length;i++)
			l.add(i,i+1);
		n=infiles.length;
		while(l.size()!=1)
		{  
		   for(int i=0;i+1<l.size();i++)
		   {
			   x=l.remove(i);
			   y=l.remove(i);
			   z=n+(i+1);
			   l.add(i, (int)z);
			   //System.out.println("merge("+x+","+y+")"+" into "+l.get(i));
			   mergeFiles(x,y,l.get(i).intValue());
		   }
		   n=z;
		}
		l.clear();
	}
	public void mergeFiles(int x,int y,int z)
	{
		String path,path1,path2=null;
		path=outdir+x+"/";
		if(x>infiles.length)
			new File(path).mkdir();
		path1=outdir+y+"/";
		if(y>infiles.length)
			new File(path1).mkdir();
		if(l.size()!=1){
		path2=outdir+z+"/";
		if(z>infiles.length)
			new File(path2).mkdir();}
		for(int i=1;i<=7;i++)
		{
			BufferedReader in1=null,in2=null;
			BufferedWriter out=null;
			String in1line=null,in2line=null;
			BufferedWriter primaryIndex=null;
			BufferedWriter metaIndex=null;
			File f1=null,f2=null;
			long offset=0,linecount=1;
			boolean flag1=true,flag2=true;
			char current,prev='!';
			String temp,temp1,temp2;
			indexOffset=0;
			try{
			switch(i)
			{
			   case 1:
				 if(l.size()==1)
				 {
					 out=new BufferedWriter(new FileWriter(outdir+"data.txt"));
					 primaryIndex=new BufferedWriter(new FileWriter(outdir+"index_data.txt"));
					 metaIndex=new BufferedWriter(new FileWriter(outdir+"metadata_data.txt"));
				 }
				 else
					 out=new BufferedWriter(new FileWriter(path2+"data.txt"));
				 in1=new BufferedReader(new FileReader(path+"data.txt"));
				 in2=new BufferedReader(new FileReader(path1+"data.txt"));
				 f1=new File(path+"data.txt");
				 f2=new File(path1+"data.txt");
				 break;
			   case 2:
					 if(l.size()==1)
					 {
						 out=new BufferedWriter(new FileWriter(outdir+"category.txt"));
						 primaryIndex=new BufferedWriter(new FileWriter(outdir+"index_category.txt"));
						 metaIndex=new BufferedWriter(new FileWriter(outdir+"metadata_category.txt"));
					 }
					 else
						 out=new BufferedWriter(new FileWriter(path2+"category.txt"));
					 in1=new BufferedReader(new FileReader(path+"category.txt"));
					 in2=new BufferedReader(new FileReader(path1+"category.txt"));
					 f1=new File(path+"category.txt");
					 f2=new File(path1+"category.txt");
					 break;
			   case 3:
					 if(l.size()==1)
					 {
						 out=new BufferedWriter(new FileWriter(outdir+"infobox.txt"));
						 primaryIndex=new BufferedWriter(new FileWriter(outdir+"index_infobox.txt"));
						 metaIndex=new BufferedWriter(new FileWriter(outdir+"metadata_infobox.txt"));
					 }
					 else
						 out=new BufferedWriter(new FileWriter(path2+"infobox.txt"));
					 in1=new BufferedReader(new FileReader(path+"infobox.txt"));
					 in2=new BufferedReader(new FileReader(path1+"infobox.txt"));
					 f1=new File(path+"infobox.txt");
					 f2=new File(path1+"infobox.txt");
					 break;
			   case 4:
					 if(l.size()==1)
					 {
						 out=new BufferedWriter(new FileWriter(outdir+"outlinks.txt"));
						 primaryIndex=new BufferedWriter(new FileWriter(outdir+"index_outlinks.txt"));
						 metaIndex=new BufferedWriter(new FileWriter(outdir+"metadata_outlinks.txt"));
					 }
					 else
						 out=new BufferedWriter(new FileWriter(path2+"outlinks.txt"));
					 in1=new BufferedReader(new FileReader(path+"outlinks.txt"));
					 in2=new BufferedReader(new FileReader(path1+"outlinks.txt"));
					 f1=new File(path+"outlinks.txt");
					 f2=new File(path1+"outlinks.txt");
					 break;
			   case 5:
					 if(l.size()==1)
					 {
						 out=new BufferedWriter(new FileWriter(outdir+"titles.txt"));
						 primaryIndex=new BufferedWriter(new FileWriter(outdir+"index_titles.txt"));
						 metaIndex=new BufferedWriter(new FileWriter(outdir+"metadata_titles.txt"));
					 }
					 else
						 out=new BufferedWriter(new FileWriter(path2+"titles.txt"));
					 in1=new BufferedReader(new FileReader(path+"titles.txt"));
					 in2=new BufferedReader(new FileReader(path1+"titles.txt"));
					 f1=new File(path+"titles.txt");
					 f2=new File(path1+"titles.txt");
					 break;
			   case 6:
					 if(l.size()==1)
					 {
						 out=new BufferedWriter(new FileWriter(outdir+"page-titles.txt"));
						 primaryIndex=new BufferedWriter(new FileWriter(outdir+"index_page-titles.txt"));
						 metaIndex=new BufferedWriter(new FileWriter(outdir+"metadata_page-titles.txt"));
					 }
					 else
						 out=new BufferedWriter(new FileWriter(path2+"page-titles.txt"));
					 in1=new BufferedReader(new FileReader(path+"page-titles.txt"));
					 in2=new BufferedReader(new FileReader(path1+"page-titles.txt"));
					 f1=new File(path+"pagetitles-.txt");
					 f2=new File(path1+"pagetitles-.txt");
					 break;
			   case 7:
					 if(l.size()==1)
					 {
						 out=new BufferedWriter(new FileWriter(outdir+"redirect.txt"));
						 primaryIndex=new BufferedWriter(new FileWriter(outdir+"index_redirect.txt"));
						 metaIndex=new BufferedWriter(new FileWriter(outdir+"metadata_redirect.txt"));
					 }
					 else
						 out=new BufferedWriter(new FileWriter(path2+"redirect.txt"));
					 in1=new BufferedReader(new FileReader(path+"redirect.txt"));
					 in2=new BufferedReader(new FileReader(path1+"redirect.txt"));
					 f1=new File(path+"redirect.txt");
					 f2=new File(path1+"redirect.txt");
					 break;
			}
			while(true)
			{
				if(flag1)
				{in1line=in1.readLine();
				if(in1line==null)
					break;}
				if(flag2){
				in2line=in2.readLine();
				if(in2line==null)
					break;}
				temp1=in1line.split("#")[0];
				temp2=in2line.split("#")[0];
				if(temp2.compareTo(temp1)>0)
				{
					out.write(in1line);
					out.write(System.getProperty("line.separator"));
					if(l.size()==1)
					{
						current=in1line.charAt(0);
						if(linecount%100==0 || prev!=current){
			            if(prev!=current)			
			            {    
						      createIndex(offset,in1line,true,primaryIndex,metaIndex);
			            }
			            else
			            {
			                  createIndex(offset,in1line,false,primaryIndex,metaIndex);	
			            }
						}
						prev=current;
			            offset+=in1line.length()+2;
			            linecount++;
					}
					flag1=true;
					flag2=false;
				}
				else if(temp2.compareTo(temp1)<0)
				{
					out.write(in2line);
					out.write(System.getProperty("line.separator"));
					if(l.size()==1)
					{
						current=in2line.charAt(0);
						if(linecount%100==0 || prev!=current){
			            if(prev!=current)			
			            {  
						     createIndex(offset,in2line,true,primaryIndex,metaIndex);
			            }
			            else
			            {
			                  createIndex(offset,in2line,false,primaryIndex,metaIndex);	
			            }}
			            offset+=in2line.length()+2;
			            prev=current;
			            linecount++;

					}
					flag1=false;
					flag2=true;
				}
				else
				{
					temp=in1line+in2line.substring(in2line.indexOf('#'));
					out.write(temp);
					out.write(System.getProperty("line.separator"));
					if(l.size()==1)
					{
						current=in1line.charAt(0);
						if(linecount%100==0 || prev!=current){
			            if(prev!=current)			
			            {    
						      createIndex(offset,in1line,true,primaryIndex,metaIndex);
			            }
			            else
			            {
			                  createIndex(offset,in1line,false,primaryIndex,metaIndex);
			            }}
			            offset+=temp.length()+2;
			            prev=current;
			            linecount++;
					}
					flag1=flag2=true;
				}
			}
			while((in1line=in1.readLine())!=null)
			{
				out.write(in1line);
				out.write(System.getProperty("line.separator"));
				if(l.size()==1)
				{
					current=in1line.charAt(0);
					if(linecount%100==0 || prev!=current){
		            if(prev!=current)			
		            {    
					      createIndex(offset,in1line,true,primaryIndex,metaIndex);
		            }
		            else
		            {
		            	  createIndex(offset,in1line,false,primaryIndex,metaIndex);
		            }}
		            offset+=in1line.length()+2;
		            prev=current;
		            linecount++;
				}
			}
			while((in2line=in2.readLine())!=null)
			{
				out.write(in2line);
				out.write(System.getProperty("line.separator"));
				if(l.size()==1)
				{
					current=in2line.charAt(0);
					if(linecount%100==0 || prev!=current){
		            if(prev!=current)			
		            {    
					      createIndex(offset,in2line,true,primaryIndex,metaIndex);
		            }
		            else
		            {
		                  createIndex(offset,in2line,false,primaryIndex,metaIndex);
		            }}
		            offset+=in2line.length()+2;
		            prev=current;
		            linecount++;
				}
			}
			//log("merged ("+x+","+y+") into"+z);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				try{
				in1.close();
				in2.close();
				out.flush();
				out.close();
				if(f1.delete());
					//log("file-"+x+"deleted("+index+")");
				if(f2.delete());
					//log("file-"+y+"deleted("+index+")");
				if(l.size()==1)
				{
					   primaryIndex.flush();
					   primaryIndex.close();
					   metaIndex.flush();
					   metaIndex.close();
				}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}
	    File f1=new File(path);
		File[] files1=f1.listFiles();
		for(File f:files1)
		{
			f.delete();
		}
		f1.delete();
		
		File f2=new File(path1);
		File[] files2=f2.listFiles();
		for(File f:files2)
		{
			f.delete();
		}
		f2.delete();
		
	}

	
	public void createIndex(long offset,String s,boolean metadata,BufferedWriter primaryIndex,BufferedWriter metaIndex)
	{
		String l;
			try{
			
		   	if(metadata)
		   	{
		   	   metaIndex.write(indexOffset+"");
		   	   metaIndex.write(System.getProperty("line.separator"));
		   	}
		   	s=s.substring(0, s.indexOf('#'));
		   	l=s+"#"+offset;
		   	primaryIndex.write(l);
		   	primaryIndex.write(System.getProperty("line.separator"));
		   	indexOffset+=l.length()+2;
		   	}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}

	public void countDocuments(long count)
	{
		pageCount+=count;
	}
	
	public void writenoOfDocuments() throws IOException
	{
		BufferedWriter bw=new BufferedWriter(new FileWriter(outdir+"noOfDocuments.txt"));
		bw.write(pageCount+"");
		bw.write(System.getProperty("line.separator"));
		bw.flush();
		bw.close();	
	}
	
}

class NewThread1 implements Runnable {
	  Thread t;
	  int name;
	  ParseDocuments s;
	  String f;
	  NewThread1(int threadname,ParseDocuments obj,String file) throws IOException {
	    name = threadname;
	    f=file;
	    t = new Thread(this, name+"");
	  	s=obj;
	    t.start();
	  }

	  // This is the entry point for thread.
	  public void run() {
	    try {
	     
	    	int index;
	    	Test2 obj=null;
	    	index=Integer.parseInt(t.getName());
	    	if(new File(s.outdir+index).mkdir())
	    	{
	    		obj=new Test2(s.indir+f,s.outdir+index+"/");
	    	}
	    	synchronized(obj)
	    	{
	    	   s.countDocuments(obj.pageCount);
	    	}
	    } catch (Exception e) {
	      System.out.println(name + "Interrupted");
	    }
	  }
	}